export type OrderStatus = 'pending' | 'confirmed' | 'preparing' | 'ready' | 'completed' | 'cancelled';

export interface SizePricing {
  [sizeKey: string]: number;
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: 'burgers' | 'pizza' | 'chips' | 'wings' | 'rice' | 'drinks';
  imageUrl: string;
  availableSizes?: string[];
  sizePricing?: SizePricing;
  isAvailable: boolean;
  rating?: number;
  reviewsCount?: number;
  originalPrice?: number;
}

export interface CartItem {
  cartId: string;
  menuItemId: string;
  name: string;
  selectedSize?: string;
  unitPrice: number;
  quantity: number;
  imageUrl: string;
}

export interface OrderItem {
  name: string;
  size?: string;
  qty: number;
  unitPrice: number;
  total: number;
}

export interface Order {
  id: string;
  customerName: string;
  customerPhone: string;
  items: OrderItem[];
  subtotal: number;
  pickupLocation: string;
  total: number;
  paymentMethod: 'Cash on pickup';
  status: OrderStatus;
  createdAt: string;
  notes?: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  avatarLetter: string;
  ordersCount: number;
  loyaltyPoints: number;
  status: 'Active' | 'Free Meal Ready';
}

export interface Testimonial {
  id: string;
  customerName: string;
  avatarLetter: string;
  timeAgo: string;
  rating: number;
  comment: string;
  status: 'pending' | 'published';
}

export interface BusinessSettings {
  businessName: string;
  whatsappNumber: string;
  currency: string;
  pickupLocations: string;
  paymentInstructions: string;
  pointsForFreeMeal: number;
}
