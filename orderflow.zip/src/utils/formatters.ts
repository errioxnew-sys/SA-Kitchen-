import { OrderItem } from '../types';

export function formatMWK(amount: number): string {
  return `MWK ${Math.round(amount).toLocaleString('en-US')}`;
}

export function cleanPhoneForWhatsApp(phone: string): string {
  // Remove spaces, dashes, parentheses, plus signs
  const cleaned = phone.replace(/[^0-9]/g, '');
  // If user provided 088... or 099... without country code, prepend 265 for Malawi
  if (cleaned.startsWith('0') && cleaned.length === 10) {
    return '265' + cleaned.slice(1);
  }
  if (!cleaned.startsWith('265') && cleaned.length === 9) {
    return '265' + cleaned;
  }
  return cleaned || '265883536872';
}

export interface GenerateWhatsAppOrderParams {
  businessName: string;
  items: OrderItem[];
  subtotal: number;
  pickupLocation?: string;
  total: number;
  customerName?: string;
  customerPhone?: string;
  notes?: string;
  paymentInstructions?: string;
}

export function generateWhatsAppOrderMessage({
  businessName,
  items,
  subtotal,
  pickupLocation = 'In-store pick up',
  total,
  paymentInstructions = 'KINDLY SEND YOUR BANK ACCOUNT or YOUR PAYMENT DETAILS',
}: GenerateWhatsAppOrderParams): string {
  const lines: string[] = [];

  lines.push(`*NEW ORDER - ${businessName}*`);
  lines.push('--------------------------------');

  items.forEach((item, index) => {
    const sizeText = item.size && item.size !== 'Regular' ? ` (${item.size})` : '';
    lines.push(`${index + 1}. *${item.name}*${sizeText}`);
    lines.push(`   Qty: ${item.qty} x ${formatMWK(item.unitPrice)} = ${formatMWK(item.total)}`);
    lines.push('');
  });

  // Remove trailing blank line before separator
  if (lines[lines.length - 1] === '') {
    lines.pop();
  }

  lines.push('--------------------------------');
  lines.push(`*Subtotal:* ${formatMWK(subtotal)}`);
  lines.push(`*Pickup:* ${pickupLocation}`);
  lines.push(`*Total Amount:* ${formatMWK(total)}`);
  lines.push('');
  lines.push(paymentInstructions || 'KINDLY SEND YOUR BANK ACCOUNT or YOUR PAYMENT DETAILS');

  return lines.join('\n');
}

export function openWhatsAppOrder(
  phoneNumber: string,
  params: GenerateWhatsAppOrderParams
) {
  const message = generateWhatsAppOrderMessage(params);
  const targetPhone = cleanPhoneForWhatsApp(phoneNumber);
  const url = `https://wa.me/${targetPhone}?text=${encodeURIComponent(message)}`;
  window.open(url, '_blank', 'noopener,noreferrer');
}
