import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { CustomerHeader } from './components/CustomerHeader';
import { CustomerHome } from './components/CustomerHome';
import { CustomerAccount } from './components/CustomerAccount';
import { AdminDashboard } from './components/AdminDashboard';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { FloatingNav } from './components/FloatingNav';
import { Toast } from './components/Toast';

const AppContent: React.FC = () => {
  const { currentView, isCheckoutOpen, setIsCheckoutOpen } = useApp();

  return (
    <div className="min-h-screen bg-cream text-ink flex flex-col selection:bg-maroon selection:text-white">
      {currentView === 'admin' ? (
        <AdminDashboard />
      ) : (
        <>
          <CustomerHeader />
          <main className="flex-1">
            {currentView === 'customer' ? <CustomerHome /> : <CustomerAccount />}
          </main>
          <FloatingNav />
        </>
      )}

      {/* Global Modals & Drawers */}
      <CartDrawer />
      <CheckoutModal isOpen={isCheckoutOpen} onClose={() => setIsCheckoutOpen(false)} />
      <Toast />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
