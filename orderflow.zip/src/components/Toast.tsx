import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';

export const Toast: React.FC = () => {
  const { toastMessage } = useApp();
  const [visible, setVisible] = useState(false);
  const [displayedText, setDisplayedText] = useState('');

  useEffect(() => {
    if (toastMessage) {
      setDisplayedText(toastMessage);
      setVisible(true);
      const timer = setTimeout(() => {
        setVisible(false);
      }, 2400);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  if (!visible) return null;

  return (
    <div
      id="global-toast"
      className="fixed bottom-24 lg:bottom-28 left-1/2 -translate-x-1/2 z-50 pointer-events-none transition-all duration-300 animate-fadeIn"
    >
      <div className="bg-ink text-white text-[13px] font-semibold px-5 py-3.5 rounded-2xl shadow-2xl flex items-center gap-2.5 border border-white/10">
        <span className="w-2 h-2 rounded-full bg-gold shrink-0"></span>
        <span>{displayedText}</span>
      </div>
    </div>
  );
};
