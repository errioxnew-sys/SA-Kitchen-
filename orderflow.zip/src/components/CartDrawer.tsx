import React from 'react';
import { useApp } from '../context/AppContext';
import { formatMWK, openWhatsAppOrder } from '../utils/formatters';
import { X, Trash2, Plus, Minus, ShoppingBag, Send, ArrowRight, ShieldCheck } from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    cartTotal,
    cartCount,
    updateCartQuantity,
    removeFromCart,
    clearCart,
    setIsCheckoutOpen,
    settings,
    currentCustomer,
  } = useApp();

  if (!isCartOpen) return null;

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleQuickWhatsApp = () => {
    openWhatsAppOrder(settings.whatsappNumber, {
      businessName: settings.businessName,
      items: cart.map((ci) => ({
        name: ci.name,
        size: ci.selectedSize,
        qty: ci.quantity,
        unitPrice: ci.unitPrice,
        total: ci.unitPrice * ci.quantity,
      })),
      subtotal: cartTotal,
      pickupLocation: 'In-store pick up',
      total: cartTotal,
      customerName: currentCustomer.name,
      customerPhone: currentCustomer.phone,
      paymentInstructions: settings.paymentInstructions,
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-fadeIn">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-ink/40 backdrop-blur-xs transition-opacity"
        onClick={() => setIsCartOpen(false)}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <aside
          id="cart-drawer-panel"
          className="w-screen max-w-md bg-white shadow-2xl flex flex-col border-l border-maroon/10"
        >
          {/* Header */}
          <div className="p-5 sm:p-6 bg-cream-soft border-b border-maroon/5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-2xl bg-maroon/10 grid place-items-center text-maroon">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h2 className="font-serif text-xl sm:text-2xl font-black text-maroon">Your Cart</h2>
                <p className="text-xs text-ink-soft">
                  {cartCount} {cartCount === 1 ? 'item' : 'items'} ready for pickup
                </p>
              </div>
            </div>

            <button
              id="close-cart-drawer-btn"
              onClick={() => setIsCartOpen(false)}
              className="w-9 h-9 grid place-items-center rounded-full hover:bg-maroon/5 text-ink-soft hover:text-maroon transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart items list */}
          <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-4 no-scrollbar">
            {cart.length === 0 ? (
              <div className="text-center py-16 space-y-3">
                <div className="w-16 h-16 rounded-full bg-cream-deep text-ink-faint mx-auto grid place-items-center text-2xl">
                  🛒
                </div>
                <h3 className="font-serif text-lg font-bold text-maroon">Your cart is empty</h3>
                <p className="text-xs text-ink-soft max-w-xs mx-auto">
                  Browse our bestsellers like Burgers, Pizza, BBQ Wings, or Rice and Fillet!
                </p>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="mt-3 inline-block bg-maroon text-white text-xs font-bold px-6 py-2.5 rounded-full hover:bg-maroon-dark transition cursor-pointer"
                >
                  Explore Menu
                </button>
              </div>
            ) : (
              <>
                <div className="flex justify-between items-center text-xs text-ink-faint pb-1">
                  <span>Selected items</span>
                  <button
                    onClick={clearCart}
                    className="text-maroon hover:text-maroon-dark font-semibold transition cursor-pointer"
                  >
                    Clear all
                  </button>
                </div>

                {cart.map((item) => (
                  <div
                    key={item.cartId}
                    className="flex gap-3 bg-cream-soft/60 p-3 rounded-2xl border border-maroon/5 items-center hover:border-maroon/20 transition"
                  >
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      className="w-16 h-16 rounded-xl object-cover shrink-0"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-1">
                        <h4 className="font-bold text-xs sm:text-sm text-ink truncate leading-tight">
                          {item.name}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.cartId)}
                          className="text-ink-faint hover:text-red-600 transition p-1 cursor-pointer"
                          title="Remove item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {item.selectedSize && (
                        <span className="inline-block bg-white text-maroon text-[10px] font-bold px-2 py-0.5 rounded-md border border-maroon/10 mt-0.5">
                          Size: {item.selectedSize}
                        </span>
                      )}

                      <div className="flex items-center justify-between mt-2">
                        <span className="text-xs font-black text-maroon">
                          {formatMWK(item.unitPrice * item.quantity)}
                        </span>

                        <div className="flex items-center gap-2 bg-white rounded-full border border-maroon/10 px-2 py-0.5 shadow-2xs">
                          <button
                            onClick={() => updateCartQuantity(item.cartId, -1)}
                            className="w-5 h-5 grid place-items-center text-maroon hover:bg-maroon/5 rounded-full transition cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="text-xs font-bold text-ink w-4 text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => updateCartQuantity(item.cartId, 1)}
                            className="w-5 h-5 grid place-items-center text-maroon hover:bg-maroon/5 rounded-full transition cursor-pointer"
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Cash on Pickup Security Explainer */}
                <div className="bg-cream-deep/60 rounded-2xl p-3.5 border border-maroon/10 flex items-start gap-2.5">
                  <ShieldCheck className="w-5 h-5 text-maroon shrink-0 mt-0.5" />
                  <div className="text-[11px] text-ink-soft leading-relaxed">
                    <strong className="text-maroon font-bold">100% Cash on Pickup: </strong>
                    Zero cyber risk. You pay strictly when receiving your order in-store, or request account details on WhatsApp.
                  </div>
                </div>
              </>
            )}
          </div>

          {/* Footer with subtotal & actions */}
          {cart.length > 0 && (
            <div className="p-5 sm:p-6 bg-cream-soft border-t border-maroon/10 space-y-3">
              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-ink-soft">
                  <span>Subtotal</span>
                  <span className="font-semibold">{formatMWK(cartTotal)}</span>
                </div>
                <div className="flex justify-between text-ink-soft">
                  <span>Pickup Fee</span>
                  <span className="text-green-700 font-bold uppercase text-[10px]">Free (In-store)</span>
                </div>
                <div className="flex justify-between text-sm font-black text-maroon pt-2 border-t border-maroon/10">
                  <span>Total Amount</span>
                  <span className="font-serif text-lg">{formatMWK(cartTotal)}</span>
                </div>
              </div>

              {/* Direct Order on WhatsApp */}
              <button
                id="cart-drawer-whatsapp-btn"
                onClick={handleQuickWhatsApp}
                className="w-full inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1FB855] text-white text-xs sm:text-sm font-bold py-3 rounded-full transition shadow-soft cursor-pointer"
              >
                <Send className="w-4 h-4" />
                Direct Order on WhatsApp
              </button>

              {/* Proceed to Cash on Pick Checkout */}
              <button
                id="cart-drawer-checkout-btn"
                onClick={handleProceedToCheckout}
                className="w-full inline-flex items-center justify-center gap-2 bg-maroon text-white text-xs sm:text-sm font-bold py-3 rounded-full hover:bg-maroon-dark transition shadow-soft cursor-pointer"
              >
                <span>Proceed to Cash on Pick</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
};
