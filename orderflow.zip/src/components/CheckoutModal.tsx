import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatMWK, generateWhatsAppOrderMessage, openWhatsAppOrder } from '../utils/formatters';
import { OrderItem, Order } from '../types';
import {
  X,
  CheckCircle2,
  ShieldCheck,
  Send,
  Building2,
  Phone,
  User,
  FileText,
  Copy,
  Check,
} from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({ isOpen, onClose }) => {
  const { cart, cartTotal, settings, createOrder, currentCustomer, showToast, setCurrentView } = useApp();

  const [customerName, setCustomerName] = useState(currentCustomer.name || '');
  const [customerPhone, setCustomerPhone] = useState(currentCustomer.phone || '');
  const [pickupBranch, setPickupBranch] = useState(
    settings.pickupLocations.split('·')[0]?.trim() || 'Area 47, Lilongwe'
  );
  const [notes, setNotes] = useState('');
  const [copied, setCopied] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  if (!isOpen) return null;

  const orderItems: OrderItem[] = cart.map((ci) => ({
    name: ci.name,
    size: ci.selectedSize,
    qty: ci.quantity,
    unitPrice: ci.unitPrice,
    total: ci.unitPrice * ci.quantity,
  }));

  const pickupLocationFull = `In-store pick up (${pickupBranch})`;

  // WhatsApp formatted message
  const whatsappPreview = generateWhatsAppOrderMessage({
    businessName: settings.businessName,
    items: orderItems,
    subtotal: cartTotal,
    pickupLocation: pickupLocationFull,
    total: cartTotal,
    customerName,
    customerPhone,
    notes,
    paymentInstructions: settings.paymentInstructions,
  });

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(whatsappPreview);
    setCopied(true);
    showToast('WhatsApp order message copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDirectWhatsApp = () => {
    openWhatsAppOrder(settings.whatsappNumber, {
      businessName: settings.businessName,
      items: orderItems,
      subtotal: cartTotal,
      pickupLocation: pickupLocationFull,
      total: cartTotal,
      customerName,
      customerPhone,
      notes,
      paymentInstructions: settings.paymentInstructions,
    });
    showToast('Opening WhatsApp with your order details...');
  };

  const handleConfirmOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !customerPhone.trim()) {
      showToast('Please enter your name and phone number');
      return;
    }

    const order = createOrder({
      customerName,
      customerPhone,
      pickupLocation: pickupLocationFull,
      notes,
    });

    setCompletedOrder(order);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-ink/60 backdrop-blur-sm animate-fadeIn">
      <div
        id="checkout-modal"
        className="relative bg-white rounded-3xl shadow-2xl w-full max-w-xl max-h-[92vh] flex flex-col overflow-hidden border border-maroon/10"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-maroon/5 bg-cream-soft">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-gold"></span>
            <h2 className="font-serif text-xl sm:text-2xl font-black text-maroon">
              {completedOrder ? 'Order Confirmed!' : 'Request Purchase & Cash on Pick'}
            </h2>
          </div>
          <button
            id="close-checkout-btn"
            onClick={() => {
              setCompletedOrder(null);
              onClose();
            }}
            className="w-9 h-9 grid place-items-center rounded-full hover:bg-maroon/5 text-ink-soft hover:text-maroon transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5 no-scrollbar">
          {completedOrder ? (
            /* Success View */
            <div className="text-center py-4 space-y-4">
              <div className="w-16 h-16 rounded-full bg-green-100 text-green-700 mx-auto grid place-items-center">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h3 className="font-serif text-2xl font-black text-maroon">
                Order {completedOrder.id} Placed!
              </h3>
              <p className="text-sm text-ink-soft max-w-md mx-auto leading-relaxed">
                Thank you, <span className="font-bold text-ink">{completedOrder.customerName}</span>.
                Your order is received and queued for preparation. Remember: you pay{' '}
                <span className="font-bold text-maroon">Cash on Pickup</span> at the counter.
              </p>

              <div className="bg-cream-soft rounded-2xl p-4 border border-maroon/10 text-left text-xs space-y-2 max-w-md mx-auto">
                <div className="flex justify-between">
                  <span className="text-ink-faint">Pickup Branch:</span>
                  <span className="font-semibold text-ink">{completedOrder.pickupLocation}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-ink-faint">Total to Pay:</span>
                  <span className="font-black text-maroon text-sm">{formatMWK(completedOrder.total)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-ink-faint">Payment Method:</span>
                  <span className="font-bold text-green-700 bg-green-50 px-2 py-0.5 rounded-full">
                    Cash on Pickup
                  </span>
                </div>
              </div>

              {/* Direct WhatsApp button after order placement */}
              <div className="pt-2 flex flex-col sm:flex-row gap-3 justify-center max-w-md mx-auto">
                <button
                  id="whatsapp-after-order-btn"
                  onClick={() => {
                    openWhatsAppOrder(settings.whatsappNumber, {
                      businessName: settings.businessName,
                      items: completedOrder.items,
                      subtotal: completedOrder.subtotal,
                      pickupLocation: completedOrder.pickupLocation,
                      total: completedOrder.total,
                      customerName: completedOrder.customerName,
                      customerPhone: completedOrder.customerPhone,
                      paymentInstructions: settings.paymentInstructions,
                    });
                  }}
                  className="inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1FB855] text-white text-sm font-bold px-6 py-3.5 rounded-full transition shadow-soft cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  Send Order to WhatsApp
                </button>

                <button
                  onClick={() => {
                    setCompletedOrder(null);
                    onClose();
                    setCurrentView('account');
                  }}
                  className="bg-maroon text-white text-sm font-bold px-6 py-3.5 rounded-full hover:bg-maroon-dark transition cursor-pointer"
                >
                  Track in My Account
                </button>
              </div>
            </div>
          ) : (
            /* Checkout Form */
            <form onSubmit={handleConfirmOrder} className="space-y-4">
              {/* Payment Method Notice (Cash on Pick only) */}
              <div className="bg-gradient-to-r from-cream-deep via-cream to-cream-soft border border-maroon/15 rounded-2xl p-4 flex items-start gap-3">
                <div className="w-9 h-9 rounded-xl bg-maroon/10 grid place-items-center text-maroon shrink-0 mt-0.5">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div className="text-xs text-ink-soft">
                  <div className="font-bold text-maroon text-[13px] flex items-center gap-2">
                    Payment Method: <span className="bg-gold/25 text-maroon-dark px-2.5 py-0.5 rounded-full font-black">Cash on Pickup</span>
                  </div>
                  <p className="mt-1 leading-relaxed">
                    No card or bank details required on this website. You pay physically when picking up your food in-store, or request bank details directly on WhatsApp.
                  </p>
                </div>
              </div>

              {/* Customer Inputs */}
              <div className="grid sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5 flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5" /> Full Name
                  </label>
                  <input
                    id="checkout-name-input"
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Ashley Phoya"
                    className="w-full px-4 py-2.5 rounded-xl bg-cream-soft border border-maroon/10 text-sm focus:outline-none focus:border-maroon/40 transition"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5 flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5" /> Phone Number
                  </label>
                  <input
                    id="checkout-phone-input"
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="e.g. 099 123 4567"
                    className="w-full px-4 py-2.5 rounded-xl bg-cream-soft border border-maroon/10 text-sm focus:outline-none focus:border-maroon/40 transition"
                  />
                </div>
              </div>

              {/* Pickup Branch */}
              <div>
                <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5 flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5" /> Pickup Location
                </label>
                <select
                  id="checkout-branch-select"
                  value={pickupBranch}
                  onChange={(e) => setPickupBranch(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-cream-soft border border-maroon/10 text-sm focus:outline-none focus:border-maroon/40 transition cursor-pointer"
                >
                  <option value="Area 47, Lilongwe">Area 47, Lilongwe (Main Kitchen)</option>
                  <option value="City Centre">City Centre Branch</option>
                  <option value="Old Town">Old Town Branch</option>
                </select>
              </div>

              {/* Order Notes */}
              <div>
                <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5 flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5" /> Special Instructions (Optional)
                </label>
                <input
                  id="checkout-notes-input"
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Extra napkins, spicy relish on the side"
                  className="w-full px-4 py-2 rounded-xl bg-cream-soft border border-maroon/10 text-sm focus:outline-none focus:border-maroon/40 transition"
                />
              </div>

              {/* WhatsApp Message Preview Accordion / Box */}
              <div className="border border-maroon/10 rounded-2xl p-3.5 bg-cream-soft/70">
                <div className="flex items-center justify-between mb-2">
                  <div className="text-[11px] font-black uppercase tracking-wider text-maroon flex items-center gap-1.5">
                    <Send className="w-3.5 h-3.5 text-[#25D366]" />
                    WhatsApp Order Preview
                  </div>
                  <button
                    type="button"
                    onClick={handleCopyMessage}
                    className="inline-flex items-center gap-1 text-[11px] font-bold text-maroon hover:text-maroon-dark transition cursor-pointer"
                  >
                    {copied ? <Check className="w-3 h-3 text-green-600" /> : <Copy className="w-3 h-3" />}
                    {copied ? 'Copied' : 'Copy'}
                  </button>
                </div>
                <pre className="font-mono text-[11px] text-ink bg-white p-3 rounded-xl border border-maroon/10 overflow-x-auto whitespace-pre-wrap leading-relaxed shadow-inner">
                  {whatsappPreview}
                </pre>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex flex-col sm:flex-row gap-3">
                {/* Primary Option 1: Direct Order on WhatsApp */}
                <button
                  type="button"
                  id="direct-whatsapp-order-btn"
                  onClick={handleDirectWhatsApp}
                  className="flex-1 inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1FB855] text-white text-[13px] font-bold py-3.5 px-4 rounded-full transition shadow-soft cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                  Order on WhatsApp
                </button>

                {/* Primary Option 2: Place Order (Cash on Pick) in App */}
                <button
                  type="submit"
                  id="submit-cash-pickup-order-btn"
                  className="flex-1 inline-flex items-center justify-center gap-2 bg-maroon text-white text-[13px] font-bold py-3.5 px-4 rounded-full hover:bg-maroon-dark transition shadow-soft cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Confirm Cash on Pick ({formatMWK(cartTotal)})
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
