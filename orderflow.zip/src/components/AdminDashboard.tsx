import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatMWK, openWhatsAppOrder } from '../utils/formatters';
import { MenuItem, Order, OrderStatus } from '../types';
import {
  LayoutDashboard,
  ClipboardList,
  UtensilsCrossed,
  Users,
  Star,
  Settings,
  LogOut,
  Search,
  Bell,
  ArrowUpRight,
  Plus,
  Trash2,
  Edit,
  X,
  Menu as MenuIcon,
  CheckCircle,
  Clock,
  ExternalLink,
  DollarSign,
  AlertTriangle,
  Send,
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const {
    adminSubSection,
    setAdminSubSection,
    setCurrentView,
    orders,
    updateOrderStatus,
    menuItems,
    addMenuItem,
    updateMenuItem,
    deleteMenuItem,
    customers,
    testimonials,
    approveTestimonial,
    hideTestimonial,
    settings,
    updateSettings,
    showToast,
  } = useApp();

  // Mobile sidebar drawer
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Search in admin
  const [adminSearch, setAdminSearch] = useState('');

  // Bookings filter
  const [bookingFilter, setBookingFilter] = useState<'all' | OrderStatus>('all');

  // Selected order for detailed modal
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // Menu item modal (Add / Edit)
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [formName, setFormName] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formPrice, setFormPrice] = useState('');
  const [formCategory, setFormCategory] = useState<'burgers' | 'pizza' | 'chips' | 'wings' | 'rice' | 'drinks'>('burgers');
  const [formImageUrl, setFormImageUrl] = useState('');
  const [formIsAvailable, setFormIsAvailable] = useState(true);
  const [formSizes, setFormSizes] = useState<string[]>(['Regular']);

  // Settings form state
  const [settingsBusinessName, setSettingsBusinessName] = useState(settings.businessName);
  const [settingsWhatsapp, setSettingsWhatsapp] = useState(settings.whatsappNumber);
  const [settingsCurrency, setSettingsCurrency] = useState(settings.currency);
  const [settingsLocations, setSettingsLocations] = useState(settings.pickupLocations);
  const [settingsInstructions, setSettingsInstructions] = useState(settings.paymentInstructions);
  const [settingsPoints, setSettingsPoints] = useState(settings.pointsForFreeMeal);

  // Filtered orders
  const filteredOrders = orders.filter((o) => {
    const matchesFilter = bookingFilter === 'all' || o.status === bookingFilter;
    const matchesSearch =
      !adminSearch.trim() ||
      o.id.toLowerCase().includes(adminSearch.toLowerCase()) ||
      o.customerName.toLowerCase().includes(adminSearch.toLowerCase()) ||
      o.customerPhone.includes(adminSearch);
    return matchesFilter && matchesSearch;
  });

  // Open modal to add new product
  const handleOpenAddProduct = () => {
    setEditingItem(null);
    setFormName('');
    setFormDescription('');
    setFormPrice('');
    setFormCategory('burgers');
    setFormImageUrl('https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=700&q=80&auto=format&fit=crop');
    setFormIsAvailable(true);
    setFormSizes(['Regular']);
    setIsProductModalOpen(true);
  };

  // Open modal to edit product
  const handleOpenEditProduct = (item: MenuItem) => {
    setEditingItem(item);
    setFormName(item.name);
    setFormDescription(item.description);
    setFormPrice(item.price.toString());
    setFormCategory(item.category);
    setFormImageUrl(item.imageUrl);
    setFormIsAvailable(item.isAvailable);
    setFormSizes(item.availableSizes && item.availableSizes.length > 0 ? item.availableSizes : ['Regular']);
    setIsProductModalOpen(true);
  };

  // Save product (Add or Update)
  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const priceNum = parseFloat(formPrice) || 10000;

    if (editingItem) {
      updateMenuItem({
        ...editingItem,
        name: formName,
        description: formDescription,
        price: priceNum,
        category: formCategory,
        imageUrl: formImageUrl || editingItem.imageUrl,
        isAvailable: formIsAvailable,
        availableSizes: formSizes,
      });
    } else {
      addMenuItem({
        name: formName,
        description: formDescription,
        price: priceNum,
        category: formCategory,
        imageUrl: formImageUrl || 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=700&q=80&auto=format&fit=crop',
        isAvailable: formIsAvailable,
        availableSizes: formSizes,
        rating: 5.0,
        reviewsCount: 1,
      });
    }

    setIsProductModalOpen(false);
  };

  // Save business settings
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      businessName: settingsBusinessName,
      whatsappNumber: settingsWhatsapp,
      currency: settingsCurrency,
      pickupLocations: settingsLocations,
      paymentInstructions: settingsInstructions,
      pointsForFreeMeal: Number(settingsPoints) || 100,
    });
  };

  // Status badge styling helper
  const getStatusBadgeStyle = (status: OrderStatus) => {
    switch (status) {
      case 'pending':
        return 'bg-gold/25 text-maroon-dark';
      case 'confirmed':
        return 'bg-blue-100 text-blue-700';
      case 'preparing':
        return 'bg-maroon/10 text-maroon';
      case 'ready':
        return 'bg-purple-100 text-purple-700';
      case 'completed':
        return 'bg-green-100 text-green-700';
      case 'cancelled':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const pendingCount = orders.filter((o) => o.status === 'pending').length;
  const completedCount = orders.filter((o) => o.status === 'completed').length;
  const totalRevenue = orders
    .filter((o) => o.status !== 'cancelled')
    .reduce((sum, o) => sum + o.total, 0);

  return (
    <div id="admin-dashboard-container" className="min-h-screen bg-cream text-ink flex flex-col antialiased">
      {/* ============================================================
           MOBILE TOPBAR
           ============================================================ */}
      <div className="lg:hidden sticky top-0 z-40 bg-cream/95 backdrop-blur-md border-b border-maroon/5 px-4 h-14 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsMobileSidebarOpen(true)}
            className="w-10 h-10 grid place-items-center rounded-full hover:bg-maroon/5 text-maroon cursor-pointer"
          >
            <MenuIcon className="w-5 h-5" />
          </button>
          <div className="flex items-baseline gap-1.5">
            <span className="font-serif text-lg font-black text-maroon">
              {settings.businessName.split(' ')[0] || 'Lusentic'}
            </span>
            <span className="font-script text-base text-gold font-bold">Admin</span>
          </div>
        </div>

        <button
          onClick={() => setCurrentView('customer')}
          className="bg-white border border-maroon/10 text-maroon text-xs font-bold px-3 py-1.5 rounded-full hover:bg-cream-soft transition"
        >
          View Site
        </button>
      </div>

      {/* Mobile Drawer Overlay */}
      {isMobileSidebarOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-ink/40 backdrop-blur-xs z-40"
          onClick={() => setIsMobileSidebarOpen(false)}
        />
      )}

      {/* ============================================================
           SIDEBAR
           ============================================================ */}
      <aside
        id="admin-sidebar"
        className={`fixed top-0 left-0 z-50 w-64 h-screen bg-cream-soft border-r border-maroon/5 flex flex-col transition-transform duration-300 ${
          isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0`}
      >
        <div className="px-6 py-6 border-b border-maroon/5 flex items-center justify-between">
          <div>
            <div className="flex items-baseline gap-1.5 leading-none">
              <span className="font-serif text-2xl font-black text-maroon tracking-tight">
                {settings.businessName.split(' ')[0] || 'Lusentic'}
              </span>
              <span className="font-script text-xl text-gold font-bold">Admin</span>
            </div>
            <p className="text-[10px] text-ink-faint mt-1.5 uppercase tracking-widest font-black">
              Management Panel
            </p>
          </div>

          <button
            onClick={() => setIsMobileSidebarOpen(false)}
            className="lg:hidden text-ink-faint hover:text-maroon p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation links */}
        <nav className="flex-1 overflow-y-auto no-scrollbar px-3 py-4 space-y-1">
          <button
            onClick={() => {
              setAdminSubSection('dashboard');
              setIsMobileSidebarOpen(false);
            }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-[13px] font-semibold transition text-left cursor-pointer ${
              adminSubSection === 'dashboard'
                ? 'bg-maroon text-white shadow-soft font-bold'
                : 'text-ink-soft hover:bg-maroon/5'
            }`}
          >
            <LayoutDashboard className="w-[18px] h-[18px]" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => {
              setAdminSubSection('bookings');
              setIsMobileSidebarOpen(false);
            }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-[13px] font-semibold transition text-left cursor-pointer ${
              adminSubSection === 'bookings'
                ? 'bg-maroon text-white shadow-soft font-bold'
                : 'text-ink-soft hover:bg-maroon/5'
            }`}
          >
            <ClipboardList className="w-[18px] h-[18px]" />
            <span>Bookings</span>
            {pendingCount > 0 && (
              <span
                className={`ml-auto text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  adminSubSection === 'bookings' ? 'bg-gold text-maroon-dark' : 'bg-maroon text-white'
                }`}
              >
                {pendingCount}
              </span>
            )}
          </button>

          <button
            onClick={() => {
              setAdminSubSection('menu');
              setIsMobileSidebarOpen(false);
            }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-[13px] font-semibold transition text-left cursor-pointer ${
              adminSubSection === 'menu'
                ? 'bg-maroon text-white shadow-soft font-bold'
                : 'text-ink-soft hover:bg-maroon/5'
            }`}
          >
            <UtensilsCrossed className="w-[18px] h-[18px]" />
            <span>Menu Items</span>
          </button>

          <button
            onClick={() => {
              setAdminSubSection('customers');
              setIsMobileSidebarOpen(false);
            }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-[13px] font-semibold transition text-left cursor-pointer ${
              adminSubSection === 'customers'
                ? 'bg-maroon text-white shadow-soft font-bold'
                : 'text-ink-soft hover:bg-maroon/5'
            }`}
          >
            <Users className="w-[18px] h-[18px]" />
            <span>Customers</span>
          </button>

          <button
            onClick={() => {
              setAdminSubSection('testimonials');
              setIsMobileSidebarOpen(false);
            }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-[13px] font-semibold transition text-left cursor-pointer ${
              adminSubSection === 'testimonials'
                ? 'bg-maroon text-white shadow-soft font-bold'
                : 'text-ink-soft hover:bg-maroon/5'
            }`}
          >
            <Star className="w-[18px] h-[18px]" />
            <span>Testimonials</span>
            {testimonials.filter((t) => t.status === 'pending').length > 0 && (
              <span
                className={`ml-auto text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  adminSubSection === 'testimonials'
                    ? 'bg-gold text-maroon-dark'
                    : 'bg-gold text-maroon-dark'
                }`}
              >
                {testimonials.filter((t) => t.status === 'pending').length}
              </span>
            )}
          </button>

          <button
            onClick={() => {
              setAdminSubSection('settings');
              setIsMobileSidebarOpen(false);
            }}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-[13px] font-semibold transition text-left cursor-pointer ${
              adminSubSection === 'settings'
                ? 'bg-maroon text-white shadow-soft font-bold'
                : 'text-ink-soft hover:bg-maroon/5'
            }`}
          >
            <Settings className="w-[18px] h-[18px]" />
            <span>Settings</span>
          </button>
        </nav>

        {/* Footer Admin User profile */}
        <div className="p-3 border-t border-maroon/5">
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-2xl hover:bg-maroon/5 transition">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-maroon to-gold grid place-items-center text-white text-[13px] font-black">
              A
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[12px] font-bold truncate">Admin User</div>
              <div className="text-[10px] text-ink-faint truncate">admin@lusentic.mw</div>
            </div>
          </div>
          <button
            onClick={() => {
              setCurrentView('customer');
              showToast('Switched back to customer view');
            }}
            className="w-full mt-1 flex items-center gap-2.5 px-4 py-2 rounded-xl text-[12px] font-bold text-maroon hover:bg-maroon/5 transition cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Exit to Customer View</span>
          </button>
        </div>
      </aside>

      {/* ============================================================
           MAIN ADMIN AREA
           ============================================================ */}
      <main className="lg:ml-64 flex-1 flex flex-col min-h-screen">
        {/* Desktop Topbar */}
        <header className="hidden lg:flex sticky top-0 z-30 bg-cream/95 backdrop-blur-md border-b border-maroon/5 px-8 h-16 items-center gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-faint" />
            <input
              type="text"
              value={adminSearch}
              onChange={(e) => setAdminSearch(e.target.value)}
              placeholder="Search orders, items, customers..."
              className="w-full pl-11 pr-4 py-2 rounded-full bg-white border border-maroon/10 text-xs placeholder:text-ink-faint focus:outline-none focus:border-maroon/30 transition"
            />
            {adminSearch && (
              <button
                onClick={() => setAdminSearch('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-ink-faint hover:text-ink"
              >
                ✕
              </button>
            )}
          </div>

          <div className="ml-auto flex items-center gap-3">
            <button
              onClick={() => showToast('No unread notifications')}
              className="relative w-10 h-10 grid place-items-center rounded-full hover:bg-maroon/5 transition cursor-pointer text-maroon"
            >
              <Bell className="w-5 h-5" />
              {pendingCount > 0 && (
                <span className="absolute top-2 right-2 w-2.5 h-2.5 rounded-full bg-maroon border-2 border-cream"></span>
              )}
            </button>

            <button
              onClick={() => setCurrentView('customer')}
              className="inline-flex items-center gap-2 bg-white border border-maroon/15 text-maroon text-xs font-bold px-4 py-2.5 rounded-full hover:bg-cream-soft transition shadow-2xs cursor-pointer"
            >
              <span>View Customer Site</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </header>

        {/* Content Section Container */}
        <div className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full flex-1">
          {/* ============================================================
               1. DASHBOARD OVERVIEW
               ============================================================ */}
          {adminSubSection === 'dashboard' && (
            <section className="space-y-6 lg:space-y-8 animate-fadeIn">
              <div>
                <h1 className="font-serif text-3xl lg:text-4xl font-black text-maroon leading-tight">
                  Good morning, Admin
                </h1>
                <p className="text-ink-soft text-sm mt-1">
                  Here's what's happening at {settings.businessName} today.
                </p>
              </div>

              {/* Stats Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 lg:gap-5">
                <div className="bg-white rounded-3xl p-5 shadow-soft border border-maroon/5">
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-2xl bg-maroon/10 grid place-items-center text-maroon">
                      <ClipboardList className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold text-green-700 bg-green-50 px-2 py-0.5 rounded-full">
                      +12%
                    </span>
                  </div>
                  <div className="font-serif text-3xl font-black text-maroon">
                    {orders.length}
                  </div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-ink-faint mt-1">
                    Total Orders
                  </div>
                </div>

                <div className="bg-white rounded-3xl p-5 shadow-soft border border-maroon/5">
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-2xl bg-gold/20 grid place-items-center text-maroon">
                      <DollarSign className="w-5 h-5" />
                    </div>
                    <span className="text-[10px] font-bold text-green-700 bg-green-50 px-2 py-0.5 rounded-full">
                      +8%
                    </span>
                  </div>
                  <div className="font-serif text-2xl sm:text-3xl font-black text-maroon truncate">
                    {formatMWK(totalRevenue)}
                  </div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-ink-faint mt-1">
                    Total Revenue
                  </div>
                </div>

                <div className="bg-white rounded-3xl p-5 shadow-soft border border-maroon/5">
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-2xl bg-gold/25 grid place-items-center text-maroon-dark">
                      <Clock className="w-5 h-5" />
                    </div>
                    {pendingCount > 0 && (
                      <span className="text-[10px] font-black text-maroon bg-gold/25 px-2 py-0.5 rounded-full">
                        Needs Action
                      </span>
                    )}
                  </div>
                  <div className="font-serif text-3xl font-black text-maroon">
                    {pendingCount}
                  </div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-ink-faint mt-1">
                    Pending Orders
                  </div>
                </div>

                <div className="bg-white rounded-3xl p-5 shadow-soft border border-maroon/5">
                  <div className="flex items-center justify-between mb-3">
                    <div className="w-10 h-10 rounded-2xl bg-green-100 grid place-items-center text-green-700">
                      <CheckCircle className="w-5 h-5" />
                    </div>
                  </div>
                  <div className="font-serif text-3xl font-black text-maroon">
                    {completedCount}
                  </div>
                  <div className="text-[11px] font-bold uppercase tracking-wider text-ink-faint mt-1">
                    Completed
                  </div>
                </div>
              </div>

              {/* Two columns: Recent bookings & Popular items */}
              <div className="grid lg:grid-cols-3 gap-5 lg:gap-6">
                <div className="lg:col-span-2 bg-white rounded-3xl shadow-soft overflow-hidden border border-maroon/5">
                  <div className="flex items-center justify-between p-5 lg:p-6 border-b border-maroon/5">
                    <h2 className="font-serif text-xl font-black text-maroon">Recent Bookings</h2>
                    <button
                      onClick={() => setAdminSubSection('bookings')}
                      className="text-xs font-bold text-maroon hover:underline cursor-pointer"
                    >
                      View all →
                    </button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs">
                      <thead className="bg-cream-soft text-ink-faint text-[10px] uppercase tracking-wider font-black">
                        <tr>
                          <th className="text-left px-5 py-3">Order</th>
                          <th className="text-left px-5 py-3">Customer</th>
                          <th className="text-left px-5 py-3">Total</th>
                          <th className="text-left px-5 py-3">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {orders.slice(0, 5).map((order) => (
                          <tr key={order.id} className="border-t border-maroon/5 hover:bg-cream-soft/20">
                            <td className="px-5 py-3.5 font-bold text-ink">{order.id}</td>
                            <td className="px-5 py-3.5 text-ink-soft">{order.customerName}</td>
                            <td className="px-5 py-3.5 font-semibold text-maroon">
                              {formatMWK(order.total)}
                            </td>
                            <td className="px-5 py-3.5">
                              <span
                                className={`inline-block text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full ${getStatusBadgeStyle(
                                  order.status
                                )}`}
                              >
                                {order.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Popular items progress list */}
                <div className="bg-white rounded-3xl shadow-soft p-5 lg:p-6 border border-maroon/5">
                  <h2 className="font-serif text-xl font-black text-maroon mb-5">Popular Items</h2>
                  <div className="space-y-4">
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="font-semibold text-ink">Classic Beef Burger</span>
                        <span className="text-ink-faint font-bold">42</span>
                      </div>
                      <div className="h-2 bg-cream-deep rounded-full overflow-hidden">
                        <div className="h-full bg-maroon rounded-full" style={{ width: '90%' }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="font-semibold text-ink">Pepperoni Pizza</span>
                        <span className="text-ink-faint font-bold">35</span>
                      </div>
                      <div className="h-2 bg-cream-deep rounded-full overflow-hidden">
                        <div className="h-full bg-maroon rounded-full" style={{ width: '75%' }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="font-semibold text-ink">Rice and Fillet</span>
                        <span className="text-ink-faint font-bold">31</span>
                      </div>
                      <div className="h-2 bg-cream-deep rounded-full overflow-hidden">
                        <div className="h-full bg-maroon rounded-full" style={{ width: '68%' }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="font-semibold text-ink">Loaded Cheese Chips</span>
                        <span className="text-ink-faint font-bold">28</span>
                      </div>
                      <div className="h-2 bg-cream-deep rounded-full overflow-hidden">
                        <div className="h-full bg-maroon rounded-full" style={{ width: '60%' }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="font-semibold text-ink">BBQ Wings</span>
                        <span className="text-ink-faint font-bold">21</span>
                      </div>
                      <div className="h-2 bg-cream-deep rounded-full overflow-hidden">
                        <div className="h-full bg-maroon rounded-full" style={{ width: '45%' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          )}

          {/* ============================================================
               2. BOOKINGS SECTION (ORDERS)
               ============================================================ */}
          {adminSubSection === 'bookings' && (
            <section className="space-y-6 animate-fadeIn">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h1 className="font-serif text-3xl lg:text-4xl font-black text-maroon leading-tight">
                    Bookings
                  </h1>
                  <p className="text-ink-soft text-sm mt-1">
                    Manage incoming orders and update their fulfillment status in real-time.
                  </p>
                </div>
              </div>

              {/* Filter pills */}
              <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
                {(['all', 'pending', 'confirmed', 'preparing', 'ready', 'completed', 'cancelled'] as const).map(
                  (status) => (
                    <button
                      key={status}
                      onClick={() => setBookingFilter(status)}
                      className={`shrink-0 text-xs font-bold px-4 py-2 rounded-full transition cursor-pointer capitalize ${
                        bookingFilter === status
                          ? 'bg-maroon text-white shadow-soft'
                          : 'bg-white border border-maroon/10 text-maroon hover:border-maroon/30'
                      }`}
                    >
                      {status}
                    </button>
                  )
                )}
              </div>

              {/* Bookings Table */}
              <div className="bg-white rounded-3xl shadow-soft overflow-hidden border border-maroon/5">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs min-w-[760px]">
                    <thead className="bg-cream-soft text-ink-faint text-[10px] uppercase tracking-wider font-black">
                      <tr>
                        <th className="text-left px-5 py-3.5">Order</th>
                        <th className="text-left px-5 py-3.5">Customer</th>
                        <th className="text-left px-5 py-3.5">Items</th>
                        <th className="text-left px-5 py-3.5">Total</th>
                        <th className="text-left px-5 py-3.5">Payment</th>
                        <th className="text-left px-5 py-3.5">Status</th>
                        <th className="text-right px-5 py-3.5">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredOrders.map((order) => (
                        <tr key={order.id} className="border-t border-maroon/5 hover:bg-cream-soft/20">
                          <td className="px-5 py-3.5 font-bold text-ink">{order.id}</td>
                          <td className="px-5 py-3.5">
                            <div className="font-semibold text-ink">{order.customerName}</div>
                            <div className="text-[11px] text-ink-faint">{order.customerPhone}</div>
                          </td>
                          <td className="px-5 py-3.5 text-ink-soft max-w-[200px] truncate">
                            {order.items.map((it) => `${it.name} (${it.qty})`).join(', ')}
                          </td>
                          <td className="px-5 py-3.5 font-black text-maroon">
                            {formatMWK(order.total)}
                          </td>
                          <td className="px-5 py-3.5 text-ink-soft">
                            <span className="inline-block bg-cream-soft text-maroon font-bold text-[10px] px-2 py-0.5 rounded-full border border-maroon/10">
                              {order.paymentMethod}
                            </span>
                          </td>
                          <td className="px-5 py-3.5">
                            <select
                              value={order.status}
                              onChange={(e) =>
                                updateOrderStatus(order.id, e.target.value as OrderStatus)
                              }
                              className={`text-[11px] font-black uppercase tracking-wider px-3 py-1.5 rounded-full border-0 focus:outline-none cursor-pointer ${getStatusBadgeStyle(
                                order.status
                              )}`}
                            >
                              <option value="pending">Pending</option>
                              <option value="confirmed">Confirmed</option>
                              <option value="preparing">Preparing</option>
                              <option value="ready">Ready</option>
                              <option value="completed">Completed</option>
                              <option value="cancelled">Cancelled</option>
                            </select>
                          </td>
                          <td className="px-5 py-3.5 text-right space-x-2">
                            <button
                              onClick={() => setSelectedOrder(order)}
                              className="text-maroon hover:text-maroon-dark font-bold text-xs cursor-pointer"
                            >
                              View
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>
          )}

          {/* ============================================================
               3. MENU ITEMS MANAGEMENT
               ============================================================ */}
          {adminSubSection === 'menu' && (
            <section className="space-y-6 animate-fadeIn">
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
                <div>
                  <h1 className="font-serif text-3xl lg:text-4xl font-black text-maroon leading-tight">
                    Menu Items
                  </h1>
                  <p className="text-ink-soft text-sm mt-1">
                    Add, edit or remove items from the customer menu.
                  </p>
                </div>
                <button
                  onClick={handleOpenAddProduct}
                  className="inline-flex items-center gap-2 bg-maroon text-white text-xs font-bold px-5 py-3 rounded-full hover:bg-maroon-dark transition shadow-soft cursor-pointer self-start sm:self-auto"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Item</span>
                </button>
              </div>

              {/* Grid of menu items */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-5">
                {menuItems.map((item) => (
                  <article
                    key={item.id}
                    className="group bg-white rounded-3xl overflow-hidden shadow-soft hover:shadow-card transition-all flex flex-col border border-maroon/5"
                  >
                    <div className="relative aspect-[4/3] bg-cream-deep overflow-hidden">
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <span className="absolute top-3 left-3 bg-white/95 backdrop-blur text-[10px] font-black uppercase tracking-wider text-maroon px-2.5 py-1 rounded-full shadow-2xs">
                        {item.category}
                      </span>
                      <span
                        className={`absolute top-3 right-3 text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full text-white shadow-2xs ${
                          item.isAvailable ? 'bg-green-600' : 'bg-red-500'
                        }`}
                      >
                        {item.isAvailable ? 'Available' : 'Unavailable'}
                      </span>
                    </div>

                    <div className="p-4 flex-1 flex flex-col justify-between">
                      <div>
                        <div className="flex items-start justify-between gap-2">
                          <h3 className="font-bold text-[15px] leading-tight text-ink truncate">
                            {item.name}
                          </h3>
                          <span className="font-black text-maroon text-sm shrink-0">
                            {formatMWK(item.price)}
                          </span>
                        </div>
                        <p className="text-[11px] text-ink-faint mt-1 line-clamp-2 leading-relaxed">
                          {item.description}
                        </p>
                      </div>

                      <div className="flex items-center gap-2 mt-4 pt-3 border-t border-maroon/5">
                        <button
                          onClick={() => handleOpenEditProduct(item)}
                          className="flex-1 bg-cream-soft hover:bg-cream-deep text-maroon text-xs font-bold py-2.5 rounded-xl transition cursor-pointer"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => {
                            if (confirm(`Delete ${item.name} from menu?`)) {
                              deleteMenuItem(item.id);
                            }
                          }}
                          className="w-9 h-9 grid place-items-center rounded-xl bg-red-50 hover:bg-red-100 text-red-600 transition cursor-pointer"
                          title="Delete item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </article>
                ))}

                {/* Add new item dashed card */}
                <div
                  onClick={handleOpenAddProduct}
                  className="bg-cream-soft rounded-3xl border-2 border-dashed border-maroon/20 hover:border-maroon/40 transition-all flex flex-col items-center justify-center min-h-[260px] cursor-pointer p-6 text-center group"
                >
                  <div className="w-14 h-14 rounded-full bg-maroon/5 group-hover:bg-maroon/10 grid place-items-center mb-3 transition">
                    <Plus className="w-6 h-6 text-maroon" />
                  </div>
                  <div className="text-sm font-bold text-maroon">Add new item</div>
                  <div className="text-xs text-ink-faint mt-1">Name, price, category, sizes</div>
                </div>
              </div>
            </section>
          )}

          {/* ============================================================
               4. CUSTOMERS SECTION
               ============================================================ */}
          {adminSubSection === 'customers' && (
            <section className="space-y-6 animate-fadeIn">
              <div>
                <h1 className="font-serif text-3xl lg:text-4xl font-black text-maroon leading-tight">
                  Customers
                </h1>
                <p className="text-ink-soft text-sm mt-1">
                  Loyalty points, purchase frequency, and order history at a glance.
                </p>
              </div>

              <div className="bg-white rounded-3xl shadow-soft overflow-hidden border border-maroon/5">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs min-w-[640px]">
                    <thead className="bg-cream-soft text-ink-faint text-[10px] uppercase tracking-wider font-black">
                      <tr>
                        <th className="text-left px-5 py-3.5">Customer</th>
                        <th className="text-left px-5 py-3.5">Phone</th>
                        <th className="text-left px-5 py-3.5">Total Orders</th>
                        <th className="text-left px-5 py-3.5">Loyalty Points</th>
                        <th className="text-left px-5 py-3.5">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {customers.map((cust) => (
                        <tr key={cust.id} className="border-t border-maroon/5 hover:bg-cream-soft/20">
                          <td className="px-5 py-3.5">
                            <div className="flex items-center gap-3">
                              <div className="w-9 h-9 rounded-full bg-gradient-to-br from-maroon to-gold grid place-items-center text-white text-xs font-black">
                                {cust.avatarLetter}
                              </div>
                              <span className="font-semibold text-ink">{cust.name}</span>
                            </div>
                          </td>
                          <td className="px-5 py-3.5 text-ink-soft">{cust.phone}</td>
                          <td className="px-5 py-3.5 font-bold text-ink">{cust.ordersCount}</td>
                          <td className="px-5 py-3.5">
                            <div className="flex items-center gap-2">
                              <div className="w-24 h-2 bg-cream-deep rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-gold"
                                  style={{
                                    width: `${Math.min(
                                      100,
                                      (cust.loyaltyPoints / settings.pointsForFreeMeal) * 100
                                    )}%`,
                                  }}
                                ></div>
                              </div>
                              <span className="font-bold text-maroon">{cust.loyaltyPoints}</span>
                            </div>
                          </td>
                          <td className="px-5 py-3.5">
                            <span
                              className={`inline-block text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full ${
                                cust.status === 'Free Meal Ready'
                                  ? 'bg-gold text-maroon-dark'
                                  : 'bg-green-100 text-green-700'
                              }`}
                            >
                              {cust.status === 'Free Meal Ready'
                                ? '🎁 Free Meal Ready'
                                : cust.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </section>
          )}

          {/* ============================================================
               5. TESTIMONIALS SECTION
               ============================================================ */}
          {adminSubSection === 'testimonials' && (
            <section className="space-y-8 animate-fadeIn">
              <div>
                <h1 className="font-serif text-3xl lg:text-4xl font-black text-maroon leading-tight">
                  Testimonials
                </h1>
                <p className="text-ink-soft text-sm mt-1">
                  Approve or hide reviews submitted by customers.
                </p>
              </div>

              {/* Pending Approval */}
              <div>
                <h2 className="text-[11px] font-black tracking-widest uppercase text-maroon mb-3">
                  Pending Approval ({testimonials.filter((t) => t.status === 'pending').length})
                </h2>

                <div className="space-y-3">
                  {testimonials
                    .filter((t) => t.status === 'pending')
                    .map((t) => (
                      <div
                        key={t.id}
                        className="bg-white rounded-3xl p-5 shadow-soft border-l-4 border-gold flex items-start justify-between gap-4 flex-wrap"
                      >
                        <div className="flex-1 min-w-[240px]">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-maroon to-gold grid place-items-center text-white text-[13px] font-black">
                              {t.avatarLetter}
                            </div>
                            <div>
                              <div className="font-bold text-sm text-ink">{t.customerName}</div>
                              <div className="text-[11px] text-ink-faint">{t.timeAgo}</div>
                            </div>
                            <div className="ml-2 text-gold text-sm">
                              {'★'.repeat(t.rating)}
                              {'☆'.repeat(5 - t.rating)}
                            </div>
                          </div>
                          <p className="text-xs sm:text-[13px] text-ink-soft leading-relaxed">
                            "{t.comment}"
                          </p>
                        </div>

                        <div className="flex gap-2">
                          <button
                            onClick={() => approveTestimonial(t.id)}
                            className="bg-maroon text-white text-xs font-bold px-4 py-2 rounded-full hover:bg-maroon-dark transition cursor-pointer"
                          >
                            Approve
                          </button>
                          <button
                            onClick={() => hideTestimonial(t.id)}
                            className="bg-cream-soft text-maroon text-xs font-bold px-4 py-2 rounded-full hover:bg-cream-deep transition cursor-pointer"
                          >
                            Hide
                          </button>
                        </div>
                      </div>
                    ))}

                  {testimonials.filter((t) => t.status === 'pending').length === 0 && (
                    <div className="p-6 bg-white rounded-2xl text-center text-xs text-ink-soft border border-maroon/5">
                      No reviews pending approval right now.
                    </div>
                  )}
                </div>
              </div>

              {/* Published */}
              <div>
                <h2 className="text-[11px] font-black tracking-widest uppercase text-ink-faint mb-3">
                  Published Reviews
                </h2>
                <div className="space-y-3">
                  {testimonials
                    .filter((t) => t.status === 'published')
                    .map((t) => (
                      <div key={t.id} className="bg-white rounded-3xl p-5 shadow-soft flex items-start gap-3">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-maroon to-gold grid place-items-center text-white text-[13px] font-black shrink-0">
                          {t.avatarLetter}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-bold text-sm text-ink">{t.customerName}</span>
                            <span className="text-gold text-sm">
                              {'★'.repeat(t.rating)}
                              {'☆'.repeat(5 - t.rating)}
                            </span>
                            <span className="text-[10px] font-bold text-green-700 bg-green-50 px-2 py-0.5 rounded-full">
                              Published
                            </span>
                          </div>
                          <p className="text-xs text-ink-soft mt-1.5 leading-relaxed">
                            "{t.comment}"
                          </p>
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </section>
          )}

          {/* ============================================================
               6. SETTINGS SECTION
               ============================================================ */}
          {adminSubSection === 'settings' && (
            <section className="space-y-6 animate-fadeIn">
              <div>
                <h1 className="font-serif text-3xl lg:text-4xl font-black text-maroon leading-tight">
                  Settings
                </h1>
                <p className="text-ink-soft text-sm mt-1">
                  Business info, contact details, and payment instructions.
                </p>
              </div>

              <div className="bg-white rounded-3xl shadow-soft p-6 lg:p-8 max-w-3xl border border-maroon/5">
                <form onSubmit={handleSaveSettings} className="space-y-5">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="sm:col-span-2">
                      <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5">
                        Business Name
                      </label>
                      <input
                        type="text"
                        required
                        value={settingsBusinessName}
                        onChange={(e) => setSettingsBusinessName(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-2xl bg-cream-soft border border-maroon/10 text-sm focus:outline-none focus:border-maroon/30 transition"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5">
                        WhatsApp Number
                      </label>
                      <input
                        type="text"
                        required
                        value={settingsWhatsapp}
                        onChange={(e) => setSettingsWhatsapp(e.target.value)}
                        placeholder="+265 88 353 6872"
                        className="w-full px-4 py-2.5 rounded-2xl bg-cream-soft border border-maroon/10 text-sm focus:outline-none focus:border-maroon/30 transition"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5">
                        Currency
                      </label>
                      <input
                        type="text"
                        required
                        value={settingsCurrency}
                        onChange={(e) => setSettingsCurrency(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-2xl bg-cream-soft border border-maroon/10 text-sm focus:outline-none focus:border-maroon/30 transition"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5">
                        Pickup Locations
                      </label>
                      <input
                        type="text"
                        value={settingsLocations}
                        onChange={(e) => setSettingsLocations(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-2xl bg-cream-soft border border-maroon/10 text-sm focus:outline-none focus:border-maroon/30 transition"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5">
                        Payment Instructions (Appended to WhatsApp Orders)
                      </label>
                      <textarea
                        rows={2}
                        value={settingsInstructions}
                        onChange={(e) => setSettingsInstructions(e.target.value)}
                        className="w-full px-4 py-2.5 rounded-2xl bg-cream-soft border border-maroon/10 text-sm focus:outline-none focus:border-maroon/30 transition resize-none"
                      />
                      <p className="text-[11px] text-ink-faint mt-1">
                        Default requested by customer: "KINDLY SEND YOUR BANK ACCOUNT or YOUR PAYMENT DETAILS"
                      </p>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5">
                        Loyalty Points for Free Meal
                      </label>
                      <input
                        type="number"
                        value={settingsPoints}
                        onChange={(e) => setSettingsPoints(Number(e.target.value))}
                        className="w-32 px-4 py-2 rounded-2xl bg-cream-soft border border-maroon/10 text-sm font-bold text-maroon focus:outline-none focus:border-maroon/30 transition"
                      />
                    </div>
                  </div>

                  <div className="pt-4 flex gap-3">
                    <button
                      type="submit"
                      className="bg-maroon text-white text-xs font-bold px-6 py-3 rounded-full hover:bg-maroon-dark transition shadow-soft cursor-pointer"
                    >
                      Save Changes
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSettingsBusinessName(settings.businessName);
                        setSettingsWhatsapp(settings.whatsappNumber);
                        setSettingsLocations(settings.pickupLocations);
                        setSettingsInstructions(settings.paymentInstructions);
                        setSettingsPoints(settings.pointsForFreeMeal);
                        showToast('Reverted changes');
                      }}
                      className="bg-cream-soft text-maroon text-xs font-bold px-6 py-3 rounded-full hover:bg-cream-deep transition cursor-pointer"
                    >
                      Reset
                    </button>
                  </div>
                </form>
              </div>
            </section>
          )}
        </div>
      </main>

      {/* ============================================================
           MODAL: VIEW ORDER DETAILS
           ============================================================ */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-ink/50 backdrop-blur-sm animate-fadeIn">
          <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto no-scrollbar border border-maroon/10">
            <div className="sticky top-0 bg-white z-10 flex items-center justify-between px-6 py-4 border-b border-maroon/5">
              <div>
                <h3 className="font-serif text-xl font-black text-maroon">
                  Order {selectedOrder.id}
                </h3>
                <p className="text-[11px] text-ink-faint">Placed {selectedOrder.createdAt}</p>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="w-8 h-8 grid place-items-center rounded-full hover:bg-maroon/5 text-ink-faint hover:text-maroon cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div className="bg-cream-soft p-4 rounded-2xl border border-maroon/5 space-y-2">
                <div className="flex justify-between">
                  <span className="text-ink-faint">Customer:</span>
                  <span className="font-bold text-ink">{selectedOrder.customerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-ink-faint">Phone:</span>
                  <span className="font-semibold text-ink">{selectedOrder.customerPhone}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-ink-faint">Pickup Branch:</span>
                  <span className="font-semibold text-ink">{selectedOrder.pickupLocation}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-ink-faint">Payment:</span>
                  <span className="font-bold text-maroon">{selectedOrder.paymentMethod}</span>
                </div>
                {selectedOrder.notes && (
                  <div className="pt-2 border-t border-maroon/10">
                    <span className="text-ink-faint block">Instructions:</span>
                    <span className="font-medium italic text-ink">{selectedOrder.notes}</span>
                  </div>
                )}
              </div>

              <div>
                <div className="text-[10px] font-black uppercase tracking-wider text-ink-faint mb-2">
                  Items List
                </div>
                <div className="space-y-2">
                  {selectedOrder.items.map((it, idx) => (
                    <div
                      key={idx}
                      className="flex justify-between items-center py-2 border-b border-maroon/5"
                    >
                      <div>
                        <span className="font-bold text-ink">{it.name}</span>
                        {it.size && (
                          <span className="text-[10px] text-maroon font-semibold ml-1">
                            ({it.size})
                          </span>
                        )}
                        <span className="text-ink-faint text-[11px] block">
                          Qty: {it.qty} × {formatMWK(it.unitPrice)}
                        </span>
                      </div>
                      <span className="font-black text-maroon">{formatMWK(it.total)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex justify-between items-center text-sm font-black text-maroon border-t border-maroon/10">
                <span>Total Amount</span>
                <span className="font-serif text-lg">{formatMWK(selectedOrder.total)}</span>
              </div>

              {/* Quick WhatsApp contact with customer */}
              <div className="pt-4 flex gap-3">
                <button
                  onClick={() => {
                    openWhatsAppOrder(selectedOrder.customerPhone, {
                      businessName: settings.businessName,
                      items: selectedOrder.items,
                      subtotal: selectedOrder.subtotal,
                      pickupLocation: selectedOrder.pickupLocation,
                      total: selectedOrder.total,
                      customerName: selectedOrder.customerName,
                      customerPhone: selectedOrder.customerPhone,
                      paymentInstructions: settings.paymentInstructions,
                    });
                  }}
                  className="flex-1 inline-flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1FB855] text-white font-bold py-2.5 rounded-full transition cursor-pointer text-xs"
                >
                  <Send className="w-3.5 h-3.5" />
                  Chat on WhatsApp
                </button>

                <button
                  onClick={() => setSelectedOrder(null)}
                  className="bg-cream-soft text-maroon font-bold px-5 py-2.5 rounded-full hover:bg-cream-deep transition cursor-pointer text-xs"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================
           MODAL: ADD / EDIT MENU ITEM
           ============================================================ */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-ink/50 backdrop-blur-sm animate-fadeIn">
          <div className="relative bg-white rounded-3xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto no-scrollbar border border-maroon/10">
            <div className="sticky top-0 bg-white z-10 flex items-center justify-between px-6 py-4 border-b border-maroon/5">
              <h2 className="font-serif text-xl sm:text-2xl font-black text-maroon">
                {editingItem ? 'Edit Menu Item' : 'Add Menu Item'}
              </h2>
              <button
                onClick={() => setIsProductModalOpen(false)}
                className="w-8 h-8 grid place-items-center rounded-full hover:bg-maroon/5 text-ink-faint hover:text-maroon cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5">
                  Item Name
                </label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. Classic Beef Burger"
                  className="w-full px-4 py-2.5 rounded-xl bg-cream-soft border border-maroon/10 text-sm focus:outline-none focus:border-maroon/30 transition"
                />
              </div>

              <div>
                <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5">
                  Description
                </label>
                <textarea
                  rows={2}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Short appetizing description"
                  className="w-full px-4 py-2.5 rounded-xl bg-cream-soft border border-maroon/10 text-sm focus:outline-none focus:border-maroon/30 transition resize-none"
                />
              </div>

              <div className="grid sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5">
                    Price (MWK)
                  </label>
                  <input
                    type="number"
                    required
                    value={formPrice}
                    onChange={(e) => setFormPrice(e.target.value)}
                    placeholder="16000"
                    className="w-full px-4 py-2.5 rounded-xl bg-cream-soft border border-maroon/10 text-sm focus:outline-none focus:border-maroon/30 transition"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5">
                    Category
                  </label>
                  <select
                    value={formCategory}
                    onChange={(e) =>
                      setFormCategory(
                        e.target.value as 'burgers' | 'pizza' | 'chips' | 'wings' | 'rice' | 'drinks'
                      )
                    }
                    className="w-full px-4 py-2.5 rounded-xl bg-cream-soft border border-maroon/10 text-sm focus:outline-none focus:border-maroon/30 transition cursor-pointer"
                  >
                    <option value="burgers">Burgers</option>
                    <option value="pizza">Pizza</option>
                    <option value="chips">Chips</option>
                    <option value="wings">Wings</option>
                    <option value="rice">Rice & Fillet</option>
                    <option value="drinks">Drinks</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-1.5">
                  Photo URL
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={formImageUrl}
                    onChange={(e) => setFormImageUrl(e.target.value)}
                    placeholder="https://images.unsplash.com/..."
                    className="flex-1 px-4 py-2.5 rounded-xl bg-cream-soft border border-maroon/10 text-xs focus:outline-none focus:border-maroon/30 transition"
                  />
                  {formImageUrl && (
                    <img
                      src={formImageUrl}
                      alt="Preview"
                      className="w-10 h-10 rounded-xl object-cover border border-maroon/10 shrink-0"
                    />
                  )}
                </div>
              </div>

              <div className="pt-1">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={formIsAvailable}
                    onChange={(e) => setFormIsAvailable(e.target.checked)}
                    className="w-4 h-4 rounded text-maroon accent-maroon"
                  />
                  <span className="font-semibold text-xs text-ink">
                    Available for customer orders
                  </span>
                </label>
              </div>

              <div className="pt-3 flex gap-3 border-t border-maroon/10">
                <button
                  type="submit"
                  className="flex-1 bg-maroon text-white text-xs font-bold py-3 rounded-full hover:bg-maroon-dark transition shadow-soft cursor-pointer"
                >
                  Save Item
                </button>
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="bg-cream-soft text-maroon text-xs font-bold px-5 py-3 rounded-full hover:bg-cream-deep transition cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
