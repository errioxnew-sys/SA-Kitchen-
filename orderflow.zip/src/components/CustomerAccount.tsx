import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatMWK, openWhatsAppOrder } from '../utils/formatters';
import { OrderStatus } from '../types';
import {
  Gift,
  Clock,
  CheckCircle2,
  AlertCircle,
  Flame,
  Package,
  Check,
  Send,
  Heart,
  Star,
  ArrowRight,
} from 'lucide-react';

export const CustomerAccount: React.FC = () => {
  const {
    currentCustomer,
    orders,
    menuItems,
    addToCart,
    favourites,
    toggleFavourite,
    submitTestimonial,
    showToast,
    settings,
    updateOrderStatus,
  } = useApp();

  // Find the customer's most recent active order, or default to latest order
  const customerOrders = orders.filter(
    (o) => o.customerName.toLowerCase() === currentCustomer.name.toLowerCase()
  );
  const activeOrder = customerOrders.find(
    (o) => o.status === 'pending' || o.status === 'confirmed' || o.status === 'preparing' || o.status === 'ready'
  ) || orders[0];

  // Star rating review state
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [reviewComment, setReviewComment] = useState<string>('');
  const [reviewSubmitted, setReviewSubmitted] = useState<boolean>(false);

  const ratingLabels: { [key: number]: string } = {
    1: 'Poor',
    2: 'Fair',
    3: 'Good',
    4: 'Great',
    5: 'Excellent!',
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewComment.trim()) {
      showToast('Please write a short note about your meal');
      return;
    }
    submitTestimonial(currentCustomer.name, rating, reviewComment);
    setReviewSubmitted(true);
    setReviewComment('');
  };

  // Reorder favourite
  const handleReorder = (itemId: string) => {
    const item = menuItems.find((m) => m.id === itemId);
    if (item) {
      addToCart(item);
      showToast(`${item.name} added to cart!`);
    }
  };

  // Progress steps logic for the active order
  const getStepIndex = (status: OrderStatus): number => {
    switch (status) {
      case 'pending':
        return 1;
      case 'confirmed':
        return 2;
      case 'preparing':
        return 3;
      case 'ready':
        return 4;
      case 'completed':
        return 5;
      case 'cancelled':
        return 0;
      default:
        return 1;
    }
  };

  const activeStep = activeOrder ? getStepIndex(activeOrder.status) : 1;

  // Favorite items from catalog
  const favoriteItems = menuItems.filter((m) => favourites.includes(m.id));

  return (
    <div id="customer-account-page" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-10 sm:space-y-14 pb-24">
      {/* ============================================================
           WELCOME + LOYALTY CARD
           ============================================================ */}
      <section>
        <div className="mb-6">
          <p className="font-script text-maroon text-2xl leading-none">welcome back</p>
          <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-black text-maroon leading-tight mt-1">
            Hey, {currentCustomer.name.split(' ')[0]} 👋
          </h1>
          <p className="text-ink-soft text-sm mt-1.5">
            Here's your {settings.businessName} orders and loyalty activity.
          </p>
        </div>

        {/* Loyalty card */}
        <div className="relative rounded-3xl bg-gradient-to-br from-maroon-light via-maroon to-maroon-dark overflow-hidden shadow-lift border border-maroon/20">
          <div className="absolute inset-0 dots opacity-40"></div>
          <div className="absolute -top-24 -right-20 w-72 h-72 bg-gold/15 rounded-full blur-3xl"></div>

          <div className="relative p-6 lg:p-8">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
              <div className="text-white">
                <div className="flex items-center gap-2 mb-2">
                  <Gift className="w-5 h-5 text-gold" />
                  <span className="text-[11px] font-black tracking-widest uppercase text-white/70">
                    Loyalty Rewards
                  </span>
                </div>
                <div className="font-serif text-4xl lg:text-5xl font-black leading-none">
                  {currentCustomer.loyaltyPoints}{' '}
                  <span className="text-lg lg:text-2xl text-white/60 font-sans font-bold">pts</span>
                </div>
                <p className="text-white/80 text-sm mt-2 max-w-xs">
                  {currentCustomer.loyaltyPoints >= settings.pointsForFreeMeal ? (
                    <span className="text-gold font-black">🎁 Free meal ready to claim in-store!</span>
                  ) : (
                    <>
                      Just{' '}
                      <span className="text-gold font-bold">
                        {settings.pointsForFreeMeal - currentCustomer.loyaltyPoints} points
                      </span>{' '}
                      until your next free meal!
                    </>
                  )}
                </p>
              </div>

              <div className="lg:w-80">
                <div className="flex items-center justify-between text-white/80 text-[11px] font-bold uppercase tracking-widest mb-2">
                  <span>Progress</span>
                  <span>
                    {currentCustomer.loyaltyPoints} / {settings.pointsForFreeMeal}
                  </span>
                </div>
                <div className="h-3 bg-white/15 backdrop-blur-sm rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-gold to-gold-dark rounded-full transition-all duration-700"
                    style={{
                      width: `${Math.min(
                        100,
                        (currentCustomer.loyaltyPoints / settings.pointsForFreeMeal) * 100
                      )}%`,
                    }}
                  ></div>
                </div>
                <div className="mt-4 flex items-center gap-2 text-white/70 text-[12px]">
                  <Clock className="w-4 h-4 text-gold" />
                  Earn 5 points per order + 5 bonus points for reviews!
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============================================================
           ACTIVE ORDER — STATUS TRACKER
           ============================================================ */}
      {activeOrder && (
        <section id="active-order-section">
          <div className="flex items-end justify-between gap-4 mb-4">
            <div>
              <h2 className="font-serif text-2xl lg:text-3xl font-black text-maroon leading-tight">
                Active Order
              </h2>
              <p className="text-ink-soft text-sm mt-1">
                Order <span className="font-bold text-ink">{activeOrder.id}</span> · placed {activeOrder.createdAt}
              </p>
            </div>
            <span
              className={`text-[11px] font-black uppercase tracking-wider px-3 py-1.5 rounded-full ${
                activeOrder.status === 'completed'
                  ? 'bg-green-100 text-green-700'
                  : activeOrder.status === 'cancelled'
                  ? 'bg-red-100 text-red-700'
                  : 'bg-gold/25 text-maroon-dark'
              }`}
            >
              {activeOrder.status}
            </span>
          </div>

          <div className="bg-white rounded-3xl shadow-soft p-6 lg:p-8 border border-maroon/5">
            {/* Status Steps Flow */}
            <div className="relative mb-8">
              <div className="hidden sm:block absolute top-6 left-[10%] right-[10%] h-1 bg-cream-deep">
                <div
                  className="h-full bg-maroon transition-all duration-500"
                  style={{
                    width: `${Math.min(100, Math.max(0, ((activeStep - 1) / 4) * 100))}%`,
                  }}
                ></div>
              </div>

              <div className="grid grid-cols-5 gap-2 relative">
                {/* Step 1: Received */}
                <div className="text-center">
                  <div
                    className={`w-11 h-11 sm:w-12 sm:h-12 mx-auto rounded-full grid place-items-center relative z-10 transition ${
                      activeStep >= 1 ? 'bg-maroon text-white shadow-soft' : 'bg-cream-deep text-ink-faint'
                    }`}
                  >
                    <Check className="w-5 h-5" />
                  </div>
                  <div className="text-[10px] sm:text-[11px] font-black uppercase tracking-wider text-maroon mt-2.5">
                    Received
                  </div>
                </div>

                {/* Step 2: Confirmed */}
                <div className="text-center">
                  <div
                    className={`w-11 h-11 sm:w-12 sm:h-12 mx-auto rounded-full grid place-items-center relative z-10 transition ${
                      activeStep >= 2 ? 'bg-maroon text-white shadow-soft' : 'bg-cream-deep text-ink-faint'
                    }`}
                  >
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div
                    className={`text-[10px] sm:text-[11px] font-black uppercase tracking-wider mt-2.5 ${
                      activeStep >= 2 ? 'text-maroon' : 'text-ink-faint'
                    }`}
                  >
                    Confirmed
                  </div>
                </div>

                {/* Step 3: Preparing */}
                <div className="text-center">
                  <div
                    className={`w-11 h-11 sm:w-12 sm:h-12 mx-auto rounded-full grid place-items-center relative z-10 transition ${
                      activeStep === 3
                        ? 'bg-maroon text-white ring-4 ring-gold/30 shadow-soft'
                        : activeStep > 3
                        ? 'bg-maroon text-white'
                        : 'bg-cream-deep text-ink-faint'
                    }`}
                  >
                    <Flame className={`w-5 h-5 ${activeStep === 3 ? 'animate-bounce' : ''}`} />
                  </div>
                  <div
                    className={`text-[10px] sm:text-[11px] font-black uppercase tracking-wider mt-2.5 ${
                      activeStep >= 3 ? 'text-maroon' : 'text-ink-faint'
                    }`}
                  >
                    Preparing
                  </div>
                </div>

                {/* Step 4: Ready */}
                <div className="text-center">
                  <div
                    className={`w-11 h-11 sm:w-12 sm:h-12 mx-auto rounded-full grid place-items-center relative z-10 transition ${
                      activeStep >= 4 ? 'bg-maroon text-white shadow-soft' : 'bg-cream-deep text-ink-faint'
                    }`}
                  >
                    <Package className="w-5 h-5" />
                  </div>
                  <div
                    className={`text-[10px] sm:text-[11px] font-black uppercase tracking-wider mt-2.5 ${
                      activeStep >= 4 ? 'text-maroon' : 'text-ink-faint'
                    }`}
                  >
                    Ready
                  </div>
                </div>

                {/* Step 5: Completed */}
                <div className="text-center">
                  <div
                    className={`w-11 h-11 sm:w-12 sm:h-12 mx-auto rounded-full grid place-items-center relative z-10 transition ${
                      activeStep >= 5 ? 'bg-green-700 text-white shadow-soft' : 'bg-cream-deep text-ink-faint'
                    }`}
                  >
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div
                    className={`text-[10px] sm:text-[11px] font-black uppercase tracking-wider mt-2.5 ${
                      activeStep >= 5 ? 'text-green-700' : 'text-ink-faint'
                    }`}
                  >
                    Completed
                  </div>
                </div>
              </div>
            </div>

            {/* Order Details Breakdown */}
            <div className="mt-6 pt-6 border-t border-maroon/5 grid sm:grid-cols-3 gap-5">
              <div>
                <div className="text-[10px] font-black tracking-widest uppercase text-ink-faint mb-1.5">
                  Ordered Items
                </div>
                <div className="text-[13px] text-ink-soft leading-relaxed space-y-1">
                  {activeOrder.items.map((it, idx) => (
                    <div key={idx}>
                      {it.name} {it.size ? `(${it.size})` : ''} × {it.qty}
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div className="text-[10px] font-black tracking-widest uppercase text-ink-faint mb-1.5">
                  Pickup Location
                </div>
                <div className="text-[13px] text-ink font-semibold">{activeOrder.pickupLocation}</div>
                <div className="text-[12px] font-bold text-maroon mt-1">
                  Payment: Cash on pickup
                </div>
              </div>

              <div>
                <div className="text-[10px] font-black tracking-widest uppercase text-ink-faint mb-1.5">
                  Total Due
                </div>
                <div className="font-serif text-2xl font-black text-maroon">
                  {formatMWK(activeOrder.total)}
                </div>
                <div className="text-[11px] text-ink-faint mt-0.5">Pay in-store at pickup counter</div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-6 pt-6 border-t border-maroon/5 flex flex-wrap gap-3">
              <button
                onClick={() => {
                  openWhatsAppOrder(settings.whatsappNumber, {
                    businessName: settings.businessName,
                    items: activeOrder.items,
                    subtotal: activeOrder.subtotal,
                    pickupLocation: activeOrder.pickupLocation,
                    total: activeOrder.total,
                    customerName: activeOrder.customerName,
                    customerPhone: activeOrder.customerPhone,
                    paymentInstructions: settings.paymentInstructions,
                  });
                }}
                className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1FB855] text-white text-[13px] font-bold px-5 py-2.5 rounded-full transition shadow-soft cursor-pointer"
              >
                <Send className="w-4 h-4" />
                Contact on WhatsApp
              </button>

              {activeOrder.status !== 'completed' && activeOrder.status !== 'cancelled' && (
                <button
                  onClick={() => updateOrderStatus(activeOrder.id, 'cancelled')}
                  className="bg-cream-soft hover:bg-cream-deep text-maroon text-[13px] font-bold px-5 py-2.5 rounded-full transition cursor-pointer"
                >
                  Cancel Order
                </button>
              )}
            </div>
          </div>
        </section>
      )}

      {/* ============================================================
           YOUR FAVOURITES
           ============================================================ */}
      <section>
        <div className="flex items-end justify-between gap-4 mb-5">
          <div>
            <h2 className="font-serif text-2xl lg:text-3xl font-black text-maroon leading-tight">
              Your Favourites
            </h2>
            <p className="text-ink-soft text-sm mt-1">
              Meals you've hearted — one tap to reorder.
            </p>
          </div>
        </div>

        {favoriteItems.length === 0 ? (
          <div className="bg-white rounded-3xl p-8 text-center border border-maroon/5 text-ink-soft text-sm">
            You haven't added any meals to your favourites yet. Tap the heart icon on any menu item!
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 lg:gap-5">
            {favoriteItems.map((item) => (
              <article
                key={item.id}
                className="group bg-white rounded-3xl overflow-hidden shadow-soft hover:shadow-card transition-all hover:-translate-y-1 border border-maroon/5 flex flex-col"
              >
                <div className="relative aspect-square overflow-hidden bg-cream-deep">
                  <img
                    src={item.imageUrl}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <button
                    onClick={() => toggleFavourite(item.id)}
                    className="absolute top-3 left-3 w-8 h-8 rounded-full bg-maroon text-white grid place-items-center shadow-sm cursor-pointer"
                  >
                    <Heart className="w-4 h-4 fill-current" />
                  </button>
                </div>
                <div className="p-3.5 lg:p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-semibold text-[13px] lg:text-[15px] leading-snug line-clamp-1">
                      {item.name}
                    </h3>
                    <div className="text-[11px] font-black text-maroon mt-1.5">
                      {formatMWK(item.price)}
                    </div>
                  </div>
                  <button
                    onClick={() => handleReorder(item.id)}
                    className="mt-3 w-full bg-maroon text-white text-[12px] font-bold py-2.5 rounded-xl hover:bg-maroon-dark transition cursor-pointer"
                  >
                    Reorder
                  </button>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {/* ============================================================
           ORDER HISTORY
           ============================================================ */}
      <section>
        <div className="mb-5">
          <h2 className="font-serif text-2xl lg:text-3xl font-black text-maroon leading-tight">
            Order History
          </h2>
          <p className="text-ink-soft text-sm mt-1">Your previous orders with {settings.businessName}.</p>
        </div>

        <div className="bg-white rounded-3xl shadow-soft overflow-hidden border border-maroon/5">
          <div className="overflow-x-auto">
            <table className="w-full text-[13px] min-w-[640px]">
              <thead className="bg-cream-soft text-ink-faint text-[10px] uppercase tracking-wider font-black">
                <tr>
                  <th className="text-left px-5 py-3.5">Order</th>
                  <th className="text-left px-5 py-3.5">Date</th>
                  <th className="text-left px-5 py-3.5">Items</th>
                  <th className="text-left px-5 py-3.5">Total</th>
                  <th className="text-left px-5 py-3.5">Status</th>
                  <th className="text-right px-5 py-3.5">Rate</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((order) => (
                  <tr key={order.id} className="border-t border-maroon/5 hover:bg-cream-soft/30 transition">
                    <td className="px-5 py-3.5 font-bold text-ink">{order.id}</td>
                    <td className="px-5 py-3.5 text-ink-soft">{order.createdAt}</td>
                    <td className="px-5 py-3.5 text-ink-soft">
                      {order.items.reduce((sum, it) => sum + it.qty, 0)} items
                    </td>
                    <td className="px-5 py-3.5 font-bold text-maroon">
                      {formatMWK(order.total)}
                    </td>
                    <td className="px-5 py-3.5">
                      <span
                        className={`inline-block text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full ${
                          order.status === 'completed'
                            ? 'bg-green-100 text-green-700'
                            : order.status === 'cancelled'
                            ? 'bg-red-100 text-red-700'
                            : 'bg-gold/25 text-maroon-dark'
                        }`}
                      >
                        {order.status}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      <button
                        onClick={() => {
                          document.getElementById('rate-section')?.scrollIntoView({ behavior: 'smooth' });
                        }}
                        className="text-maroon hover:text-maroon-dark font-bold text-[12px] cursor-pointer"
                      >
                        Rate →
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {/* ============================================================
           RATE YOUR VISIT & LEAVE TESTIMONIAL
           ============================================================ */}
      <section id="rate-section">
        <div className="mb-5">
          <h2 className="font-serif text-2xl lg:text-3xl font-black text-maroon leading-tight">
            Rate your last visit
          </h2>
          <p className="text-ink-soft text-sm mt-1">
            Your feedback helps us get better — and earns you +5 bonus loyalty points.
          </p>
        </div>

        <div className="bg-white rounded-3xl shadow-soft p-6 lg:p-8 max-w-3xl border border-maroon/5">
          {reviewSubmitted ? (
            <div className="flex items-start gap-4 p-4 bg-green-50 rounded-2xl border border-green-200">
              <div className="w-10 h-10 rounded-full bg-green-100 text-green-700 grid place-items-center shrink-0">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-bold text-ink text-base">Thanks for your review! 🎉</h4>
                <p className="text-xs text-ink-soft mt-1 leading-relaxed">
                  Your feedback was submitted to the admin team for approval. 5 bonus points have been added to your loyalty card.
                </p>
                <button
                  onClick={() => setReviewSubmitted(false)}
                  className="mt-3 text-xs font-bold text-maroon hover:underline cursor-pointer"
                >
                  Write another review
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleReviewSubmit} className="space-y-5">
              {/* Star selection */}
              <div>
                <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-2">
                  Your Rating
                </label>
                <div className="flex items-center gap-2">
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((starNum) => {
                      const isActive = (hoverRating || rating) >= starNum;
                      return (
                        <button
                          key={starNum}
                          type="button"
                          onMouseEnter={() => setHoverRating(starNum)}
                          onMouseLeave={() => setHoverRating(0)}
                          onClick={() => setRating(starNum)}
                          className="p-1 cursor-pointer transition transform hover:scale-110"
                        >
                          <Star
                            className={`w-8 h-8 ${
                              isActive ? 'text-gold fill-gold' : 'text-cream-deep'
                            }`}
                          />
                        </button>
                      );
                    })}
                  </div>
                  <span className="ml-3 text-sm font-bold text-ink">
                    {ratingLabels[hoverRating || rating]}
                  </span>
                </div>
              </div>

              {/* Text review */}
              <div>
                <label className="block text-[11px] font-black tracking-widest uppercase text-maroon mb-2">
                  Your Experience
                </label>
                <textarea
                  rows={4}
                  required
                  value={reviewComment}
                  onChange={(e) => setReviewComment(e.target.value)}
                  placeholder="Tell us what you loved about your meal or in-store pickup experience..."
                  className="w-full px-4 py-3 rounded-2xl bg-cream-soft border border-maroon/10 text-sm focus:outline-none focus:border-maroon/30 transition resize-none"
                ></textarea>
              </div>

              <div className="flex items-center gap-4 flex-wrap">
                <button
                  type="submit"
                  className="bg-maroon text-white text-xs font-bold px-7 py-3 rounded-full hover:bg-maroon-dark transition shadow-soft cursor-pointer"
                >
                  Submit Review
                </button>
                <span className="text-xs text-ink-faint">Earns +5 loyalty points</span>
              </div>
            </form>
          )}
        </div>
      </section>
    </div>
  );
};
