import React from 'react';
import { useApp } from '../context/AppContext';
import { ShoppingBag, Search, Shield, User, UtensilsCrossed } from 'lucide-react';

export const CustomerHeader: React.FC = () => {
  const {
    cartCount,
    setIsCartOpen,
    searchQuery,
    setSearchQuery,
    setCurrentView,
    currentView,
    currentCustomer,
    setSelectedCategory,
    settings,
  } = useApp();

  return (
    <header id="customer-header" className="sticky top-0 z-40 bg-cream/95 backdrop-blur-md border-b border-maroon/5 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top bar */}
        <div className="flex items-center gap-4 h-16 lg:h-20">
          {/* Logo */}
          <button
            id="brand-logo-btn"
            onClick={() => {
              setCurrentView('customer');
              setSelectedCategory('all');
            }}
            className="shrink-0 flex items-baseline gap-1.5 leading-none group text-left cursor-pointer"
          >
            <span className="font-serif text-2xl sm:text-3xl lg:text-[2.35rem] font-black text-maroon tracking-tight group-hover:text-maroon-dark transition">
              {settings.businessName.split(' ')[0] || 'Lusentic'}
            </span>
            <span className="font-script text-xl sm:text-2xl lg:text-[1.9rem] text-gold font-bold">
              {settings.businessName.split(' ').slice(1).join(' ') || 'Kitchen'}
            </span>
          </button>

          {/* Desktop Search */}
          <div className="hidden md:block flex-1 max-w-lg mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-faint" />
              <input
                id="desktop-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for burgers, pizza, wings, chips, or rice..."
                className="w-full pl-11 pr-4 py-2.5 rounded-full bg-white border border-maroon/10 text-sm placeholder:text-ink-faint focus:outline-none focus:border-maroon/30 focus:ring-2 focus:ring-maroon/5 transition"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-ink-faint hover:text-ink"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 sm:gap-3 ml-auto">
            {/* View Admin button */}
            <button
              id="header-admin-btn"
              onClick={() => setCurrentView('admin')}
              className="inline-flex items-center gap-1.5 bg-maroon/5 hover:bg-maroon/10 border border-maroon/15 text-maroon text-[12px] font-bold px-3.5 py-2 rounded-full transition"
              title="Open Admin Dashboard"
            >
              <Shield className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Admin Panel</span>
            </button>

            {/* Cart icon button */}
            <button
              id="header-cart-btn"
              onClick={() => setIsCartOpen(true)}
              className="relative w-10 h-10 grid place-items-center rounded-full hover:bg-maroon/5 transition cursor-pointer"
              aria-label="Open Shopping Cart"
            >
              <ShoppingBag className="w-[22px] h-[22px] text-maroon" />
              {cartCount > 0 && (
                <span
                  id="header-cart-badge"
                  className="bump-anim absolute -top-0.5 -right-0.5 min-w-[18px] h-[18px] px-1 rounded-full bg-maroon text-white text-[10px] font-bold grid place-items-center border-2 border-cream"
                >
                  {cartCount}
                </span>
              )}
            </button>

            {/* Account / Login button */}
            <button
              id="header-account-btn"
              onClick={() => setCurrentView(currentView === 'account' ? 'customer' : 'account')}
              className="flex items-center gap-2 bg-white rounded-full pl-1.5 pr-3.5 py-1.5 border border-maroon/10 hover:border-maroon/30 transition text-ink cursor-pointer"
            >
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-maroon to-gold grid place-items-center text-white text-[11px] font-black">
                {currentCustomer.avatarLetter || 'A'}
              </div>
              <span className="hidden sm:block text-[13px] font-bold text-maroon">
                {currentView === 'account' ? 'Menu' : currentCustomer.name.split(' ')[0]}
              </span>
            </button>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="md:hidden pb-3">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-ink-faint" />
            <input
              id="mobile-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for burgers, rice, pizza..."
              className="w-full pl-11 pr-4 py-2 rounded-full bg-white border border-maroon/10 text-sm placeholder:text-ink-faint focus:outline-none focus:border-maroon/30 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-ink-faint hover:text-ink"
              >
                ✕
              </button>
            )}
          </div>
        </div>

        {/* Desktop category navigation */}
        <nav className="hidden lg:flex items-center gap-6 pb-3 text-[13px] font-semibold text-ink">
          <button
            onClick={() => {
              setSelectedCategory('all');
              setCurrentView('customer');
            }}
            className="hover:text-maroon transition cursor-pointer"
          >
            All Menu
          </button>
          <button
            onClick={() => {
              setSelectedCategory('burgers');
              setCurrentView('customer');
            }}
            className="hover:text-maroon transition cursor-pointer"
          >
            Burgers
          </button>
          <button
            onClick={() => {
              setSelectedCategory('pizza');
              setCurrentView('customer');
            }}
            className="hover:text-maroon transition cursor-pointer"
          >
            Pizza
          </button>
          <button
            onClick={() => {
              setSelectedCategory('chips');
              setCurrentView('customer');
            }}
            className="hover:text-maroon transition cursor-pointer"
          >
            Chips
          </button>
          <button
            onClick={() => {
              setSelectedCategory('rice');
              setCurrentView('customer');
            }}
            className="hover:text-maroon transition cursor-pointer"
          >
            Rice & Fillet
          </button>
          <button
            onClick={() => {
              setSelectedCategory('wings');
              setCurrentView('customer');
            }}
            className="hover:text-maroon transition cursor-pointer"
          >
            Wings
          </button>
          <button
            onClick={() => {
              setSelectedCategory('drinks');
              setCurrentView('customer');
            }}
            className="hover:text-maroon transition cursor-pointer"
          >
            Drinks
          </button>

          <div className="ml-auto flex items-center gap-3">
            <span className="text-[11px] font-bold text-ink-faint uppercase tracking-wider">
              Cash on Pickup Only
            </span>
            <button
              onClick={() => {
                document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="bg-maroon text-white text-[13px] font-bold px-6 py-2 rounded-full hover:bg-maroon-dark transition shadow-soft cursor-pointer flex items-center gap-1.5"
            >
              <UtensilsCrossed className="w-3.5 h-3.5" />
              ORDER NOW
            </button>
          </div>
        </nav>
      </div>
    </header>
  );
};
