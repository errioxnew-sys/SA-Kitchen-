import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatMWK } from '../utils/formatters';
import { MenuItem } from '../types';
import {
  Heart,
  Plus,
  Star,
  Clock,
  ClipboardList,
  Users,
  Flame,
  Ticket,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

export const CustomerHome: React.FC = () => {
  const {
    menuItems,
    addToCart,
    favourites,
    toggleFavourite,
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    settings,
    showToast,
    setCurrentView,
  } = useApp();

  // For items with multiple sizes, track active size choice per card
  const [selectedSizes, setSelectedSizes] = useState<{ [itemId: string]: string }>({
    'item-rice-fillet': 'S',
    'item-pizza-pepperoni': 'Large',
  });

  const handleSizeChange = (itemId: string, size: string) => {
    setSelectedSizes((prev) => ({ ...prev, [itemId]: size }));
  };

  // Filter items by category & search query
  const filteredItems = menuItems.filter((item) => {
    const matchesCategory =
      selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch =
      !searchQuery.trim() ||
      item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div id="customer-home-page" className="space-y-12 sm:space-y-16 pb-24">
      {/* ============================================================
           HERO SECTION + FLOATING MENU CARD
           ============================================================ */}
      <section className="max-w-7xl mx-auto px-3 sm:px-4 lg:px-8 pt-4 lg:pt-6">
        <div className="relative">
          {/* Hero Banner with Maroon Gradient & Dots */}
          <div className="relative rounded-[2rem] lg:rounded-[2.5rem] overflow-hidden bg-gradient-to-br from-maroon-light via-maroon to-maroon-dark">
            <div className="absolute inset-0 dots opacity-50"></div>
            <div className="absolute -top-32 -right-24 w-80 h-80 bg-gold/10 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-32 -left-24 w-80 h-80 bg-white/10 rounded-full blur-3xl"></div>

            <div className="relative px-5 sm:px-8 lg:px-14 pt-10 lg:pt-14 pb-44 lg:pb-52">
              <div className="grid lg:grid-cols-[1fr_1.5fr_1fr] items-center gap-8 lg:gap-6">
                {/* Left circular food image */}
                <div className="hidden lg:flex justify-center">
                  <div className="relative">
                    <div className="w-56 xl:w-64 aspect-square rounded-full border-[10px] border-white/95 shadow-2xl overflow-hidden float-y">
                      <img
                        src="https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=800&q=80&auto=format&fit=crop"
                        alt="Loaded burger"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="absolute -bottom-2 -right-2 w-14 h-14 rounded-full bg-gold grid place-items-center border-4 border-maroon shadow-xl rotate-12">
                      <span className="font-serif text-2xl font-black text-maroon leading-none">★</span>
                    </div>
                  </div>
                </div>

                {/* Center text */}
                <div className="text-center order-first lg:order-none">
                  <p className="font-script text-gold text-3xl lg:text-4xl leading-none mb-2">
                    fresh from the grill
                  </p>
                  <h1 className="font-serif text-white font-black leading-[0.95] tracking-tight text-[2.5rem] sm:text-5xl lg:text-[3.75rem] xl:text-[4.25rem]">
                    HOT BURGERS.<br />
                    <span className="font-script font-bold text-gold">Loaded Chips!</span>
                  </h1>
                  <p className="text-white/80 mt-4 text-sm lg:text-base max-w-sm mx-auto leading-relaxed">
                    Burgers, pizza, wings, chips, and fragrant rice & fillet — made fresh to order with convenient cash on pickup!
                  </p>

                  <div className="mt-6 inline-flex items-center gap-2.5 bg-white/10 backdrop-blur-sm border border-white/15 rounded-full pl-4 pr-1.5 py-1.5 shadow-soft">
                    <span className="text-white text-[13px] font-medium flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-gold" /> Special Offer!
                    </span>
                    <span className="bg-gold text-maroon-dark text-[13px] font-black tracking-wide px-4 py-1.5 rounded-full">
                      SAVE 20%
                    </span>
                  </div>

                  {/* Mobile circular food preview */}
                  <div className="lg:hidden mt-8 flex justify-center">
                    <div className="w-48 sm:w-56 aspect-square rounded-full border-[8px] border-white/95 shadow-2xl overflow-hidden">
                      <img
                        src="https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=800&q=80&auto=format&fit=crop"
                        alt="Loaded burger"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                </div>

                {/* Right circular food images */}
                <div className="hidden lg:flex flex-col gap-4 items-end pr-2">
                  <div className="relative w-32 xl:w-36 aspect-square rounded-full border-[6px] border-white/95 shadow-xl overflow-hidden">
                    <img
                      src="https://images.unsplash.com/photo-1513104890138-7c749659a591?w=600&q=80&auto=format&fit=crop"
                      alt="Pizza"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="relative w-32 xl:w-36 aspect-square rounded-full border-[6px] border-white/95 shadow-xl overflow-hidden -mt-2 mr-10">
                    <img
                      src="https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=600&q=80&auto=format&fit=crop"
                      alt="Chips"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Overlapping White Menu Card */}
          <div
            id="menu-category-card"
            className="relative z-10 mx-3 sm:mx-4 lg:mx-8 -mt-32 lg:-mt-40 bg-white rounded-[1.75rem] lg:rounded-[2rem] shadow-card p-5 sm:p-7 lg:p-9 border border-maroon/5"
          >
            <div className="flex items-end justify-between gap-4 mb-5 lg:mb-7">
              <div>
                <h2 className="font-serif text-3xl lg:text-4xl font-black text-maroon leading-none">
                  Menu Categories
                </h2>
                <p className="text-ink-soft text-sm mt-1.5">What are you craving today?</p>
              </div>
              <button
                onClick={() => setSelectedCategory('all')}
                className="text-[13px] font-semibold text-maroon hover:text-maroon-dark transition inline-flex items-center gap-1 cursor-pointer"
              >
                <span>See all</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Category selection buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 lg:gap-4">
              <button
                onClick={() => setSelectedCategory('burgers')}
                className={`group rounded-2xl py-5 lg:py-6 transition-all hover:-translate-y-1 cursor-pointer text-center ${
                  selectedCategory === 'burgers'
                    ? 'bg-maroon text-white shadow-soft'
                    : 'bg-cream-soft hover:bg-cream-deep border border-maroon/5 text-maroon'
                }`}
              >
                <div className="text-3xl sm:text-4xl mb-2 group-hover:scale-110 transition-transform">🍔</div>
                <div className={`text-[11px] font-black tracking-widest uppercase ${selectedCategory === 'burgers' ? 'text-white' : 'text-maroon'}`}>
                  Burgers
                </div>
              </button>

              <button
                onClick={() => setSelectedCategory('pizza')}
                className={`group rounded-2xl py-5 lg:py-6 transition-all hover:-translate-y-1 cursor-pointer text-center ${
                  selectedCategory === 'pizza'
                    ? 'bg-maroon text-white shadow-soft'
                    : 'bg-cream-soft hover:bg-cream-deep border border-maroon/5 text-maroon'
                }`}
              >
                <div className="text-3xl sm:text-4xl mb-2 group-hover:scale-110 transition-transform">🍕</div>
                <div className={`text-[11px] font-black tracking-widest uppercase ${selectedCategory === 'pizza' ? 'text-white' : 'text-maroon'}`}>
                  Pizza
                </div>
              </button>

              <button
                onClick={() => setSelectedCategory('chips')}
                className={`group rounded-2xl py-5 lg:py-6 transition-all hover:-translate-y-1 cursor-pointer text-center ${
                  selectedCategory === 'chips'
                    ? 'bg-maroon text-white shadow-soft'
                    : 'bg-cream-soft hover:bg-cream-deep border border-maroon/5 text-maroon'
                }`}
              >
                <div className="text-3xl sm:text-4xl mb-2 group-hover:scale-110 transition-transform">🍟</div>
                <div className={`text-[11px] font-black tracking-widest uppercase ${selectedCategory === 'chips' ? 'text-white' : 'text-maroon'}`}>
                  Chips
                </div>
              </button>

              <button
                onClick={() => setSelectedCategory('wings')}
                className={`group rounded-2xl py-5 lg:py-6 transition-all hover:-translate-y-1 cursor-pointer text-center ${
                  selectedCategory === 'wings'
                    ? 'bg-maroon text-white shadow-soft'
                    : 'bg-cream-soft hover:bg-cream-deep border border-maroon/5 text-maroon'
                }`}
              >
                <div className="text-3xl sm:text-4xl mb-2 group-hover:scale-110 transition-transform">🍗</div>
                <div className={`text-[11px] font-black tracking-widest uppercase ${selectedCategory === 'wings' ? 'text-white' : 'text-maroon'}`}>
                  Wings
                </div>
              </button>

              <button
                onClick={() => setSelectedCategory('rice')}
                className={`group rounded-2xl py-5 lg:py-6 transition-all hover:-translate-y-1 cursor-pointer text-center ${
                  selectedCategory === 'rice'
                    ? 'bg-maroon text-white shadow-soft'
                    : 'bg-cream-soft hover:bg-cream-deep border border-maroon/5 text-maroon'
                }`}
              >
                <div className="text-3xl sm:text-4xl mb-2 group-hover:scale-110 transition-transform">🍚</div>
                <div className={`text-[11px] font-black tracking-widest uppercase ${selectedCategory === 'rice' ? 'text-white' : 'text-maroon'}`}>
                  Rice & Fillet
                </div>
              </button>

              <button
                onClick={() => setSelectedCategory('drinks')}
                className={`group rounded-2xl py-5 lg:py-6 transition-all hover:-translate-y-1 cursor-pointer text-center ${
                  selectedCategory === 'drinks'
                    ? 'bg-maroon text-white shadow-soft'
                    : 'bg-cream-soft hover:bg-cream-deep border border-maroon/5 text-maroon'
                }`}
              >
                <div className="text-3xl sm:text-4xl mb-2 group-hover:scale-110 transition-transform">🥤</div>
                <div className={`text-[11px] font-black tracking-widest uppercase ${selectedCategory === 'drinks' ? 'text-white' : 'text-maroon'}`}>
                  Drinks
                </div>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* ============================================================
           BESTSELLERS / MENU GRID
           ============================================================ */}
      <section id="menu" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 mb-6 lg:mb-8">
          <div>
            <h2 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-black text-maroon leading-tight">
              {selectedCategory === 'all'
                ? 'Bestsellers from the Kitchen'
                : `${selectedCategory.toUpperCase()} Menu`}
            </h2>
            <p className="text-xs sm:text-sm text-ink-soft mt-1">
              {filteredItems.length} items ready for immediate in-store pick up
            </p>
          </div>

          {selectedCategory !== 'all' && (
            <button
              onClick={() => setSelectedCategory('all')}
              className="text-xs font-bold text-maroon hover:underline self-start sm:self-auto cursor-pointer"
            >
              Show all categories
            </button>
          )}
        </div>

        {filteredItems.length === 0 ? (
          <div className="bg-white rounded-3xl p-12 text-center shadow-soft">
            <p className="text-ink-soft text-base">No menu items match your search or filter.</p>
            <button
              onClick={() => {
                setSelectedCategory('all');
              }}
              className="mt-4 bg-maroon text-white text-xs font-bold px-6 py-2.5 rounded-full hover:bg-maroon-dark transition cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
            {filteredItems.map((item) => {
              const isFav = favourites.includes(item.id);
              const currentSizeChoice =
                selectedSizes[item.id] || (item.availableSizes && item.availableSizes[0]);

              // Calculate active price based on size
              let effectivePrice = item.price;
              if (
                currentSizeChoice &&
                item.sizePricing &&
                item.sizePricing[currentSizeChoice]
              ) {
                effectivePrice = item.sizePricing[currentSizeChoice];
              }

              return (
                <article
                  key={item.id}
                  className="group bg-white rounded-3xl overflow-hidden shadow-soft hover:shadow-card transition-all hover:-translate-y-1 flex flex-col border border-maroon/5"
                >
                  {/* Image Container */}
                  <div className="relative aspect-[4/3] bg-cream-deep overflow-hidden">
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />

                    {/* Heart Favourite Button */}
                    <button
                      onClick={() => toggleFavourite(item.id)}
                      className={`absolute top-3 left-3 w-8 h-8 rounded-full grid place-items-center shadow-sm transition cursor-pointer ${
                        isFav ? 'bg-maroon text-white' : 'bg-white/95 backdrop-blur text-maroon hover:scale-110'
                      }`}
                      aria-label="Toggle favourite"
                    >
                      <Heart className={`w-4 h-4 ${isFav ? 'fill-current' : ''}`} />
                    </button>

                    {/* Stock status or category badge */}
                    <span className="absolute top-3 right-3 bg-white/95 backdrop-blur text-[10px] font-black uppercase tracking-wider text-maroon px-2.5 py-1 rounded-full shadow-2xs">
                      {item.isAvailable ? item.category : 'Unavailable'}
                    </span>
                  </div>

                  {/* Body Content */}
                  <div className="p-4 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="font-bold text-sm lg:text-[15px] leading-snug text-ink line-clamp-1">
                        {item.name}
                      </h3>
                      <p className="text-xs text-ink-faint mt-1 line-clamp-2 leading-relaxed">
                        {item.description}
                      </p>

                      {/* Sizes Choice Pills (if available) */}
                      {item.availableSizes && item.availableSizes.length > 1 && (
                        <div className="mt-3 flex items-center gap-1.5 flex-wrap">
                          <span className="text-[10px] font-bold text-ink-faint uppercase">Size:</span>
                          {item.availableSizes.map((sz) => (
                            <button
                              key={sz}
                              type="button"
                              onClick={() => handleSizeChange(item.id, sz)}
                              className={`text-[10px] font-black px-2 py-0.5 rounded-md transition cursor-pointer ${
                                currentSizeChoice === sz
                                  ? 'bg-maroon text-white shadow-2xs'
                                  : 'bg-cream-soft hover:bg-cream-deep text-ink border border-maroon/10'
                              }`}
                            >
                              {sz}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>

                    <div className="mt-4 pt-3 border-t border-maroon/5 flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-sm font-black text-maroon">
                            {formatMWK(effectivePrice)}
                          </span>
                          {item.originalPrice && (
                            <span className="text-[10px] text-ink-faint line-through">
                              {formatMWK(item.originalPrice)}
                            </span>
                          )}
                        </div>

                        {item.rating && (
                          <div className="flex items-center gap-1 text-[10px] text-ink-soft mt-0.5">
                            <span className="text-gold font-bold">★ {item.rating.toFixed(1)}</span>
                            <span>({item.reviewsCount || 100})</span>
                          </div>
                        )}
                      </div>

                      <button
                        onClick={() => addToCart(item, currentSizeChoice)}
                        disabled={!item.isAvailable}
                        className={`w-9 h-9 rounded-full grid place-items-center transition active:scale-90 cursor-pointer shadow-soft ${
                          item.isAvailable
                            ? 'bg-maroon text-white hover:bg-maroon-dark'
                            : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                        }`}
                        title={item.isAvailable ? 'Add to cart' : 'Currently sold out'}
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </section>

      {/* ============================================================
           OUR PROMISE & VALUE PROPOSITION
           ============================================================ */}
      <section id="packages" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        <div className="mb-6 lg:mb-8">
          <h2 className="font-serif text-2xl sm:text-3xl lg:text-4xl font-black text-maroon leading-tight">
            Our Promise
          </h2>
          <p className="text-ink-soft text-sm mt-1.5">
            Fresh ingredients. Real fire. No shortcuts.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 lg:gap-8">
          <div className="space-y-5">
            <div className="bg-white rounded-3xl p-5 lg:p-6 shadow-soft border border-maroon/5">
              <p className="text-sm text-ink-soft mb-5 leading-relaxed">
                Every burger pressed by hand. Every pizza stretched fresh. Fragrant rice and fish fillet cooked with aromatic herbs. Every order cooked when you order it.
              </p>

              <div className="grid grid-cols-4 gap-2 sm:gap-3">
                <div className="text-center">
                  <div className="w-11 h-11 mx-auto rounded-full bg-maroon/5 grid place-items-center mb-2">
                    <Clock className="w-5 h-5 text-maroon" />
                  </div>
                  <div className="text-[9px] sm:text-[10px] font-black tracking-wider uppercase text-maroon leading-tight">
                    Ready in<br />20 mins
                  </div>
                </div>

                <div className="text-center">
                  <div className="w-11 h-11 mx-auto rounded-full bg-maroon/5 grid place-items-center mb-2">
                    <ClipboardList className="w-5 h-5 text-maroon" />
                  </div>
                  <div className="text-[9px] sm:text-[10px] font-black tracking-wider uppercase text-maroon leading-tight">
                    30+<br />Menu Items
                  </div>
                </div>

                <div className="text-center">
                  <div className="w-11 h-11 mx-auto rounded-full bg-maroon/5 grid place-items-center mb-2">
                    <Users className="w-5 h-5 text-maroon" />
                  </div>
                  <div className="text-[9px] sm:text-[10px] font-black tracking-wider uppercase text-maroon leading-tight">
                    10k+<br />Orders
                  </div>
                </div>

                <div className="text-center">
                  <div className="w-11 h-11 mx-auto rounded-full bg-maroon/5 grid place-items-center mb-2">
                    <Flame className="w-5 h-5 text-maroon" />
                  </div>
                  <div className="text-[9px] sm:text-[10px] font-black tracking-wider uppercase text-maroon leading-tight">
                    Cooked<br />Fresh
                  </div>
                </div>
              </div>
            </div>

            {/* The Magical Ticket Card */}
            <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-cream-deep to-cream p-5 lg:p-6 shadow-soft border border-maroon/5">
              <div className="flex items-center gap-4">
                <div className="shrink-0 w-20 h-20 sm:w-24 sm:h-24 rounded-2xl bg-gold/30 grid place-items-center rotate-[-8deg] shadow-inner">
                  <div className="text-center leading-tight rotate-[8deg]">
                    <div className="text-[8px] font-black tracking-widest text-maroon-dark uppercase">Magic</div>
                    <div className="text-2xl">🎟️</div>
                    <div className="text-[8px] font-black tracking-widest text-maroon-dark uppercase">Ticket</div>
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-serif text-lg lg:text-xl font-black text-maroon leading-tight">
                    THE MAGICAL TICKET
                  </h3>
                  <p className="text-[12px] text-ink-soft mt-1.5 leading-relaxed">
                    Add 3 items to your cart. Earn bonus points towards your next free meal.
                  </p>
                  <button
                    onClick={() => {
                      showToast('Bonus ticket unlocked! 🎟️ Earned extra rewards.');
                    }}
                    className="mt-3 bg-maroon text-white text-[11px] font-black tracking-wider uppercase px-5 py-2.5 rounded-full hover:bg-maroon-dark transition cursor-pointer"
                  >
                    Unlock Now
                  </button>
                </div>
              </div>
            </div>

            {/* Social Proof */}
            <div className="flex items-center gap-3">
              <div className="flex -space-x-2.5">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-gold to-maroon border-2 border-cream overflow-hidden">
                  <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop" alt="" className="w-full h-full object-cover" />
                </div>
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-maroon to-gold border-2 border-cream overflow-hidden">
                  <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop" alt="" className="w-full h-full object-cover" />
                </div>
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-gold to-maroon border-2 border-cream overflow-hidden">
                  <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop" alt="" className="w-full h-full object-cover" />
                </div>
                <div className="w-9 h-9 rounded-full bg-maroon border-2 border-cream grid place-items-center text-white text-[10px] font-bold">
                  +9k
                </div>
              </div>
              <span className="text-[12px] font-medium text-ink-soft">Happy food lovers in Malawi!</span>
            </div>
          </div>

          {/* Food Image Mosaic */}
          <div className="grid grid-cols-2 gap-3 lg:gap-4">
            <div className="space-y-3 lg:space-y-4">
              <div className="aspect-[4/5] rounded-3xl overflow-hidden bg-maroon/10 shadow-soft">
                <img
                  src="https://images.unsplash.com/photo-1550547660-d9450f859349?w=600&q=80&auto=format&fit=crop"
                  alt="Tasty burger"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="aspect-[4/5] rounded-3xl overflow-hidden bg-maroon/10 shadow-soft">
                <img
                  src="https://images.unsplash.com/photo-1604382354936-07c5d9983bd3?w=600&q=80&auto=format&fit=crop"
                  alt="Fresh pizza"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
            </div>
            <div className="space-y-3 lg:space-y-4 pt-8">
              <div className="aspect-[4/5] rounded-3xl overflow-hidden bg-maroon/10 shadow-soft">
                <img
                  src="https://images.unsplash.com/photo-1571997478779-2adcbbe9ab2f?w=600&q=80&auto=format&fit=crop"
                  alt="Crispy wings"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="aspect-[4/5] rounded-3xl overflow-hidden bg-maroon/10 shadow-soft">
                <img
                  src="https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?w=600&q=80&auto=format&fit=crop"
                  alt="Steak burger"
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ============================================================
           BOTTOM BANNER
           ============================================================ */}
      <section id="offers" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        <div className="rounded-3xl bg-gradient-to-r from-maroon-dark via-maroon to-maroon-light px-6 py-6 lg:px-10 lg:py-7 text-center shadow-lift">
          <p className="font-serif text-white text-base sm:text-lg lg:text-xl font-bold leading-snug">
            {settings.businessName} — Your Favourite Spot for Burgers, Pizza, Chips & Rice
          </p>
        </div>
      </section>

      {/* ============================================================
           FOOTER
           ============================================================ */}
      <footer id="contact" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 border-t border-maroon/10">
        <div className="grid md:grid-cols-12 gap-8 lg:gap-10">
          <div className="md:col-span-4">
            <div className="inline-flex items-baseline gap-1.5 leading-none">
              <span className="font-serif text-3xl font-black text-maroon tracking-tight">
                {settings.businessName.split(' ')[0] || 'Lusentic'}
              </span>
              <span className="font-script text-2xl text-gold font-bold">
                {settings.businessName.split(' ').slice(1).join(' ') || 'Kitchen'}
              </span>
            </div>
            <p className="text-xs text-ink-soft mt-3 leading-relaxed">
              Wholesome food cooked fresh daily. Simple pickup and direct WhatsApp orders with guaranteed cash payment on pick.
            </p>
            <ul className="mt-4 space-y-1.5 text-[13px] text-ink-soft">
              <li><span className="font-semibold text-ink">Locations:</span> {settings.pickupLocations}</li>
              <li><span className="font-semibold text-ink">WhatsApp:</span> {settings.whatsappNumber}</li>
              <li><span className="font-semibold text-ink">Payment:</span> Cash on pickup</li>
            </ul>
          </div>

          <div className="md:col-span-2">
            <h4 className="text-[11px] font-black tracking-widest uppercase text-maroon mb-3">Quick Links</h4>
            <ul className="space-y-2 text-[13px] text-ink-soft">
              <li><button onClick={() => setSelectedCategory('all')} className="hover:text-maroon transition">All Menu</button></li>
              <li><button onClick={() => setCurrentView('account')} className="hover:text-maroon transition">My Account</button></li>
              <li><button onClick={() => setCurrentView('admin')} className="hover:text-maroon transition">Admin Dashboard</button></li>
            </ul>
          </div>

          <div className="md:col-span-3">
            <h4 className="text-[11px] font-black tracking-widest uppercase text-maroon mb-3">Payment Policy</h4>
            <p className="text-xs text-ink-soft leading-relaxed">
              We do not accept card payments online to ensure maximum security. All payments are completed cash on pickup in-store or by requested account transfer.
            </p>
          </div>

          <div className="md:col-span-3">
            <h4 className="text-[11px] font-black tracking-widest uppercase text-maroon mb-3">WhatsApp Order</h4>
            <a
              href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(`Hello ${settings.businessName}, I would like to inquire about ordering.`)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1FB855] text-white text-xs font-bold px-4 py-2.5 rounded-full transition shadow-soft"
            >
              <span>Chat with Us on WhatsApp</span>
            </a>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-maroon/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-ink-faint">
          <p>© 2026 {settings.businessName}. All rights reserved. Cash on pickup.</p>
          <div className="flex gap-2">
            <input
              type="email"
              placeholder="Enter email for offers"
              className="px-4 py-2 rounded-full bg-white border border-maroon/10 text-xs focus:outline-none focus:border-maroon/30"
            />
            <button
              onClick={() => showToast('Subscribed! 📬')}
              className="bg-maroon text-white text-xs font-bold px-5 py-2 rounded-full hover:bg-maroon-dark transition cursor-pointer"
            >
              Subscribe
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
