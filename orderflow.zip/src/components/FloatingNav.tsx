import React from 'react';
import { useApp } from '../context/AppContext';
import { Home, Utensils, ShoppingBag, User, UtensilsCrossed } from 'lucide-react';

export const FloatingNav: React.FC = () => {
  const {
    currentView,
    setCurrentView,
    cartCount,
    setIsCartOpen,
    setSelectedCategory,
  } = useApp();

  // If in admin mode, don't show the customer floating nav
  if (currentView === 'admin') return null;

  return (
    <nav
      id="floating-bottom-nav"
      className="fixed bottom-4 lg:bottom-6 left-1/2 -translate-x-1/2 z-40 w-[calc(100%-2rem)] max-w-[420px]"
    >
      <div className="bg-white/90 backdrop-blur-xl rounded-full shadow-nav border border-black/[0.04] px-2 py-2 flex items-center justify-between">
        {/* Home */}
        <button
          onClick={() => {
            setCurrentView('customer');
            setSelectedCategory('all');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className={`flex items-center gap-2 pl-4 pr-5 py-2.5 rounded-full font-semibold text-[13px] transition-all cursor-pointer ${
            currentView === 'customer'
              ? 'bg-maroon text-white shadow-soft'
              : 'text-ink-soft hover:bg-maroon/5 hover:text-maroon'
          }`}
        >
          <Home className="w-[18px] h-[18px]" />
          <span>Home</span>
        </button>

        {/* Menu scroll */}
        <button
          onClick={() => {
            if (currentView !== 'customer') {
              setCurrentView('customer');
            }
            setTimeout(() => {
              document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' });
            }, 100);
          }}
          className="w-11 h-11 grid place-items-center rounded-full text-ink-soft hover:bg-maroon/5 hover:text-maroon transition cursor-pointer"
          title="Browse Menu"
        >
          <Utensils className="w-5 h-5" />
        </button>

        {/* Cart */}
        <button
          onClick={() => setIsCartOpen(true)}
          className="relative w-11 h-11 grid place-items-center rounded-full text-ink-soft hover:bg-maroon/5 hover:text-maroon transition cursor-pointer"
          title="Shopping Cart"
        >
          <ShoppingBag className="w-5 h-5" />
          {cartCount > 0 && (
            <span
              id="floating-cart-badge"
              className="bump-anim absolute top-1 right-1 min-w-[18px] h-[18px] px-1 rounded-full bg-maroon text-white text-[10px] font-bold grid place-items-center border-2 border-white"
            >
              {cartCount}
            </span>
          )}
        </button>

        {/* Account */}
        <button
          onClick={() => setCurrentView('account')}
          className={`w-11 h-11 grid place-items-center rounded-full transition cursor-pointer ${
            currentView === 'account'
              ? 'bg-maroon text-white shadow-soft'
              : 'text-ink-soft hover:bg-maroon/5 hover:text-maroon'
          }`}
          title="My Account"
        >
          <User className="w-5 h-5" />
        </button>

        {/* Direct Order button */}
        <button
          onClick={() => {
            if (cartCount > 0) {
              setIsCartOpen(true);
            } else {
              if (currentView !== 'customer') {
                setCurrentView('customer');
              }
              setTimeout(() => {
                document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' });
              }, 100);
            }
          }}
          className="flex items-center gap-1.5 pl-4 pr-5 py-2.5 rounded-full bg-ink text-white font-semibold text-[13px] transition-all ml-1 hover:bg-black cursor-pointer shadow-soft"
        >
          <UtensilsCrossed className="w-4 h-4 text-gold" />
          <span>Order</span>
        </button>
      </div>
    </nav>
  );
};
