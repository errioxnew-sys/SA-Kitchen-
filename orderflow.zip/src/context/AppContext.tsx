import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  MenuItem,
  Order,
  Customer,
  Testimonial,
  BusinessSettings,
  CartItem,
  OrderStatus,
} from '../types';
import {
  INITIAL_MENU_ITEMS,
  INITIAL_ORDERS,
  INITIAL_CUSTOMERS,
  INITIAL_TESTIMONIALS,
  INITIAL_SETTINGS,
} from '../data/initialData';

interface AppContextType {
  // State
  currentView: 'customer' | 'account' | 'admin';
  setCurrentView: (view: 'customer' | 'account' | 'admin') => void;
  adminSubSection: 'dashboard' | 'bookings' | 'menu' | 'customers' | 'testimonials' | 'settings';
  setAdminSubSection: (section: 'dashboard' | 'bookings' | 'menu' | 'customers' | 'testimonials' | 'settings') => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;

  // Cart
  cart: CartItem[];
  cartCount: number;
  cartTotal: number;
  addToCart: (item: MenuItem, size?: string) => void;
  updateCartQuantity: (cartId: string, delta: number) => void;
  removeFromCart: (cartId: string) => void;
  clearCart: () => void;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;

  // Favorites
  favourites: string[];
  toggleFavourite: (itemId: string) => void;

  // Data
  menuItems: MenuItem[];
  addMenuItem: (item: Omit<MenuItem, 'id'>) => void;
  updateMenuItem: (item: MenuItem) => void;
  deleteMenuItem: (id: string) => void;

  orders: Order[];
  createOrder: (orderData: {
    customerName: string;
    customerPhone: string;
    pickupLocation: string;
    notes?: string;
  }) => Order;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;

  customers: Customer[];
  testimonials: Testimonial[];
  submitTestimonial: (name: string, rating: number, comment: string) => void;
  approveTestimonial: (id: string) => void;
  hideTestimonial: (id: string) => void;

  settings: BusinessSettings;
  updateSettings: (newSettings: Partial<BusinessSettings>) => void;

  // Active customer state
  currentCustomer: Customer;
  addLoyaltyPoints: (points: number) => void;

  // Toast
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  MENU: 'lusentic_menu_items',
  ORDERS: 'lusentic_orders',
  CUSTOMERS: 'lusentic_customers',
  TESTIMONIALS: 'lusentic_testimonials',
  SETTINGS: 'lusentic_settings',
  CART: 'lusentic_cart',
  FAVOURITES: 'lusentic_favourites',
};

function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const saved = localStorage.getItem(key);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (e) {
    console.warn(`Error loading storage for ${key}:`, e);
  }
  return fallback;
}

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentView, setCurrentView] = useState<'customer' | 'account' | 'admin'>('customer');
  const [adminSubSection, setAdminSubSection] = useState<'dashboard' | 'bookings' | 'menu' | 'customers' | 'testimonials' | 'settings'>('dashboard');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Load persistent states
  const [menuItems, setMenuItems] = useState<MenuItem[]>(() =>
    loadFromStorage(STORAGE_KEYS.MENU, INITIAL_MENU_ITEMS)
  );
  const [orders, setOrders] = useState<Order[]>(() =>
    loadFromStorage(STORAGE_KEYS.ORDERS, INITIAL_ORDERS)
  );
  const [customers, setCustomers] = useState<Customer[]>(() =>
    loadFromStorage(STORAGE_KEYS.CUSTOMERS, INITIAL_CUSTOMERS)
  );
  const [testimonials, setTestimonials] = useState<Testimonial[]>(() =>
    loadFromStorage(STORAGE_KEYS.TESTIMONIALS, INITIAL_TESTIMONIALS)
  );
  const [settings, setSettings] = useState<BusinessSettings>(() =>
    loadFromStorage(STORAGE_KEYS.SETTINGS, INITIAL_SETTINGS)
  );
  const [cart, setCart] = useState<CartItem[]>(() =>
    loadFromStorage(STORAGE_KEYS.CART, [])
  );
  const [favourites, setFavourites] = useState<string[]>(() =>
    loadFromStorage(STORAGE_KEYS.FAVOURITES, ['item-burger-classic', 'item-pizza-pepperoni', 'item-chips-chicken'])
  );

  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MENU, JSON.stringify(menuItems));
  }, [menuItems]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.TESTIMONIALS, JSON.stringify(testimonials));
  }, [testimonials]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FAVOURITES, JSON.stringify(favourites));
  }, [favourites]);

  // Toast handler
  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  // Cart operations
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartTotal = cart.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);

  const addToCart = (item: MenuItem, size?: string) => {
    const selectedSize = size || (item.availableSizes && item.availableSizes.length > 0 ? item.availableSizes[0] : undefined);
    let unitPrice = item.price;
    if (selectedSize && item.sizePricing && item.sizePricing[selectedSize]) {
      unitPrice = item.sizePricing[selectedSize];
    }

    const cartId = `${item.id}-${selectedSize || 'default'}`;

    setCart((prev) => {
      const existing = prev.find((ci) => ci.cartId === cartId);
      if (existing) {
        return prev.map((ci) =>
          ci.cartId === cartId ? { ...ci, quantity: ci.quantity + 1 } : ci
        );
      }
      return [
        ...prev,
        {
          cartId,
          menuItemId: item.id,
          name: item.name,
          selectedSize: selectedSize && selectedSize !== 'Regular' ? selectedSize : undefined,
          unitPrice,
          quantity: 1,
          imageUrl: item.imageUrl,
        },
      ];
    });

    const displaySize = selectedSize && selectedSize !== 'Regular' ? ` (${selectedSize})` : '';
    showToast(`${item.name}${displaySize} added to cart`);
  };

  const updateCartQuantity = (cartId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.cartId === cartId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter((item): item is CartItem => item !== null)
    );
  };

  const removeFromCart = (cartId: string) => {
    setCart((prev) => prev.filter((item) => item.cartId !== cartId));
  };

  const clearCart = () => {
    setCart([]);
  };

  // Favourites
  const toggleFavourite = (itemId: string) => {
    setFavourites((prev) => {
      if (prev.includes(itemId)) {
        showToast('Removed from favourites');
        return prev.filter((id) => id !== itemId);
      } else {
        showToast('Added to favourites ❤️');
        return [...prev, itemId];
      }
    });
  };

  // Menu items CRUD
  const addMenuItem = (itemData: Omit<MenuItem, 'id'>) => {
    const newItem: MenuItem = {
      ...itemData,
      id: `item-${Date.now()}`,
    };
    setMenuItems((prev) => [newItem, ...prev]);
    showToast('Menu item added successfully');
  };

  const updateMenuItem = (updatedItem: MenuItem) => {
    setMenuItems((prev) =>
      prev.map((item) => (item.id === updatedItem.id ? updatedItem : item))
    );
    showToast('Menu item updated');
  };

  const deleteMenuItem = (id: string) => {
    setMenuItems((prev) => prev.filter((item) => item.id !== id));
    showToast('Menu item deleted');
  };

  // Orders CRUD
  const createOrder = ({
    customerName,
    customerPhone,
    pickupLocation,
    notes,
  }: {
    customerName: string;
    customerPhone: string;
    pickupLocation: string;
    notes?: string;
  }): Order => {
    const nextNum = 1025 + orders.length;
    const newOrder: Order = {
      id: `#ORD-${nextNum}`,
      customerName: customerName || 'Ashley Phoya',
      customerPhone: customerPhone || '099 123 4567',
      items: cart.map((ci) => ({
        name: ci.name,
        size: ci.selectedSize,
        qty: ci.quantity,
        unitPrice: ci.unitPrice,
        total: ci.unitPrice * ci.quantity,
      })),
      subtotal: cartTotal,
      pickupLocation: pickupLocation || 'In-store pick up (Area 47, Lilongwe)',
      total: cartTotal,
      paymentMethod: 'Cash on pickup',
      status: 'pending',
      createdAt: 'Just now',
      notes,
    };

    setOrders((prev) => [newOrder, ...prev]);
    clearCart();

    // Reward loyalty points to active customer (+5 pts per order)
    addLoyaltyPoints(5);

    // Update or add customer in list
    setCustomers((prev) => {
      const match = prev.find((c) => c.name.toLowerCase() === (customerName || 'Ashley Phoya').toLowerCase());
      if (match) {
        return prev.map((c) =>
          c.id === match.id
            ? { ...c, ordersCount: c.ordersCount + 1, loyaltyPoints: c.loyaltyPoints + 5 }
            : c
        );
      }
      return [
        {
          id: `cust-${Date.now()}`,
          name: customerName,
          phone: customerPhone,
          avatarLetter: customerName.charAt(0).toUpperCase() || 'C',
          ordersCount: 1,
          loyaltyPoints: 10,
          status: 'Active',
        },
        ...prev,
      ];
    });

    showToast(`Order ${newOrder.id} placed! (Cash on pickup)`);
    return newOrder;
  };

  const updateOrderStatus = (orderId: string, status: OrderStatus) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status } : o))
    );
    showToast(`Order ${orderId} marked as ${status}`);
  };

  // Current customer (Ashley Phoya by default)
  const currentCustomer = customers.find((c) => c.name === 'Ashley Phoya') || customers[0] || {
    id: 'cust-1',
    name: 'Ashley Phoya',
    phone: '099 123 4567',
    avatarLetter: 'A',
    ordersCount: 12,
    loyaltyPoints: 85,
    status: 'Active',
  };

  const addLoyaltyPoints = (pts: number) => {
    setCustomers((prev) =>
      prev.map((c) =>
        c.name === currentCustomer.name
          ? {
              ...c,
              loyaltyPoints: c.loyaltyPoints + pts,
              status: c.loyaltyPoints + pts >= settings.pointsForFreeMeal ? 'Free Meal Ready' : c.status,
            }
          : c
      )
    );
  };

  // Testimonials
  const submitTestimonial = (name: string, rating: number, comment: string) => {
    const newT: Testimonial = {
      id: `test-${Date.now()}`,
      customerName: name || 'Ashley Phoya',
      avatarLetter: (name || 'Ashley').charAt(0).toUpperCase(),
      timeAgo: 'Just now',
      rating,
      comment,
      status: 'pending',
    };
    setTestimonials((prev) => [newT, ...prev]);
    addLoyaltyPoints(5);
    showToast('Review submitted! +5 bonus loyalty points 🎉');
  };

  const approveTestimonial = (id: string) => {
    setTestimonials((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: 'published' } : t))
    );
    showToast('Testimonial approved & published');
  };

  const hideTestimonial = (id: string) => {
    setTestimonials((prev) => prev.filter((t) => t.id !== id));
    showToast('Testimonial hidden');
  };

  // Settings
  const updateSettings = (newSettings: Partial<BusinessSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
    showToast('Settings saved successfully');
  };

  return (
    <AppContext.Provider
      value={{
        currentView,
        setCurrentView,
        adminSubSection,
        setAdminSubSection,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory,
        cart,
        cartCount,
        cartTotal,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        isCartOpen,
        setIsCartOpen,
        isCheckoutOpen,
        setIsCheckoutOpen,
        favourites,
        toggleFavourite,
        menuItems,
        addMenuItem,
        updateMenuItem,
        deleteMenuItem,
        orders,
        createOrder,
        updateOrderStatus,
        customers,
        testimonials,
        submitTestimonial,
        approveTestimonial,
        hideTestimonial,
        settings,
        updateSettings,
        currentCustomer,
        addLoyaltyPoints,
        toastMessage,
        showToast,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
